import { cn } from "@/lib/utils";
import type { SortDir } from "@/lib/sort";

export function SortTh({
  label,
  col,
  active,
  dir,
  onToggle,
  className,
}: {
  label: string;
  col: string;
  active: string;
  dir: SortDir;
  onToggle: (col: string) => void;
  className?: string;
}) {
  const on = active === col;
  return (
    <th className={cn("px-3 py-2 font-medium", className)} aria-sort={on ? (dir === "asc" ? "ascending" : "descending") : "none"}>
      <button
        type="button"
        className="inline-flex min-h-11 w-full items-center gap-1 text-left tracking-wide uppercase"
        onClick={() => onToggle(col)}
      >
        <span>{label}</span>
        <span className={on ? "text-foreground" : "text-muted-foreground/40"} aria-hidden>
          {on ? (dir === "asc" ? "▲" : "▼") : "↕"}
        </span>
      </button>
    </th>
  );
}
