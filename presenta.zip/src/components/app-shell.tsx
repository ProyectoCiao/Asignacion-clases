import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/lib/theme";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Oferta de clases" },
  { to: "/mapa", label: "Mapa cine" },
  { to: "/demanda", label: "Demanda" },
  { to: "/aulas", label: "Aulas" },
  { to: "/materias", label: "Materias" },
  { to: "/docentes", label: "Docentes" },
  { to: "/bajar", label: "Bajar presentación" },
  { to: "/proyecto", label: "Llevar a VS" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { theme, toggle } = useTheme();

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-[1400px] flex-col gap-3 px-4 py-4 sm:px-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-medium tracking-[0.14em] text-muted-foreground uppercase">
                UADE · Monserrat / Belgrano · 1er cuatri 2026
              </p>
              <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">
                Asignación de clases
              </h1>
            </div>
            <button
              type="button"
              onClick={toggle}
              className="inline-flex min-h-11 items-center gap-2 rounded-md border border-border bg-background px-3 text-sm font-medium"
              aria-pressed={theme === "night"}
            >
              {theme === "night" ? <Sun className="size-4" /> : <Moon className="size-4" />}
              {theme === "night" ? "Modo día" : "Modo noche"}
            </button>
          </div>
          <nav className="flex flex-wrap gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-muted hover:text-foreground"
                activeProps={{
                  className:
                    "rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary hover:text-primary-foreground",
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <div className="mx-auto max-w-[1400px] px-4 py-5 sm:px-6 sm:py-6">{children}</div>
    </div>
  );
}

export function FieldLabel({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <label className={cn("mb-1 block text-xs font-medium text-muted-foreground", className)}>
      {children}
    </label>
  );
}
