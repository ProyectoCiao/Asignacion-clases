import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { AppShell } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SortTh } from "@/components/sort-th";
import { listDemanda, listInscripciones, refreshDemanda } from "@/lib/oferta";
import { useSort } from "@/lib/sort";

export const Route = createFileRoute("/demanda")({ component: DemandaPage });

function DemandaPage() {
  const qc = useQueryClient();
  const demanda = useQuery({ queryKey: ["demanda"], queryFn: () => listDemanda() });
  const insc = useQuery({ queryKey: ["inscripciones"], queryFn: () => listInscripciones() });
  const refresh = useMutation({
    mutationFn: () => refreshDemanda(),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["demanda"] });
      void qc.invalidateQueries({ queryKey: ["inscripciones"] });
    },
  });

  const meta = demanda.data?.meta;
  const rows = demanda.data?.rows ?? [];
  const getDemanda = useCallback((r: (typeof rows)[number], key: string) => {
    const asientos = r.asientos ?? 0;
    switch (key) {
      case "materia":
        return r.materia;
      case "solicitudes":
        return r.solicitudes;
      case "clases":
        return r.clases;
      case "insc":
        return r.inscriptos_en_clases;
      case "asientos":
        return r.asientos ?? Number.NEGATIVE_INFINITY;
      case "brecha":
        return r.solicitudes - asientos;
      default:
        return "";
    }
  }, []);
  const sort = useSort(rows, getDemanda, "materia");

  const getInsc = useCallback((r: NonNullable<typeof insc.data>[number], key: string) => {
    if (key === "alumno") return r.alumno;
    if (key === "carrera") return r.carrera;
    return r.materia;
  }, []);
  const sortInsc = useSort(insc.data ?? [], getInsc, "alumno");

  return (
    <AppShell>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold">Demanda de cursada</h2>
          <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted-foreground">
            Cada alumno pide materias de su carrera. El operador actualiza cuando quiere: se
            recuentan las solicitudes y se comparan con asientos ya ofrecidos en clases.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Última actualización: {meta?.demanda_actualizada_en ?? "nunca"}
          </p>
        </div>
        <Button disabled={refresh.isPending} onClick={() => refresh.mutate()}>
          {refresh.isPending ? "Actualizando…" : "Actualizar demanda"}
        </Button>
      </div>

      {refresh.data ? (
        <p className="mb-3 rounded-md bg-ok-soft px-3 py-2 text-sm text-ok">
          Recuento listo. {refresh.data.solicitudes} solicitudes en el período.
        </p>
      ) : null}

      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs tracking-wide text-muted-foreground uppercase">
            <tr>
              <SortTh label="Materia" col="materia" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Solicitudes" col="solicitudes" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Clases" col="clases" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Insc. en clases" col="insc" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Asientos" col="asientos" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Brecha" col="brecha" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
            </tr>
          </thead>
          <tbody>
            {sort.sorted.map((r) => {
              const asientos = r.asientos ?? 0;
              const brecha = r.solicitudes - asientos;
              return (
                <tr key={r.materia_codigo} className="border-b border-border">
                  <td className="px-3 py-2">
                    <div className="font-medium">{r.materia}</div>
                    <div className="text-xs text-muted-foreground">
                      {r.materia_codigo} · {r.facultad}
                    </div>
                  </td>
                  <td className="px-3 py-2 font-mono">{r.solicitudes}</td>
                  <td className="px-3 py-2 font-mono">{r.clases}</td>
                  <td className="px-3 py-2 font-mono">{r.inscriptos_en_clases}</td>
                  <td className="px-3 py-2 font-mono">{r.asientos ?? "—"}</td>
                  <td className="px-3 py-2">
                    {brecha > 0 ? (
                      <Badge tone="warn">+{brecha} sin asiento</Badge>
                    ) : (
                      <Badge tone="ok">{brecha}</Badge>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <h3 className="mt-8 mb-2 text-sm font-semibold">Solicitudes (muestra)</h3>
      <p className="mb-3 text-xs text-muted-foreground">
        Códigos de alumno de prueba, no personas reales. En producción vendrían del sistema de
        inscripciones.
      </p>
      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs text-muted-foreground uppercase">
            <tr>
              <SortTh label="Alumno" col="alumno" active={sortInsc.key} dir={sortInsc.dir} onToggle={sortInsc.toggle} />
              <SortTh label="Carrera" col="carrera" active={sortInsc.key} dir={sortInsc.dir} onToggle={sortInsc.toggle} />
              <SortTh label="Materia" col="materia" active={sortInsc.key} dir={sortInsc.dir} onToggle={sortInsc.toggle} />
            </tr>
          </thead>
          <tbody>
            {sortInsc.sorted.slice(0, 80).map((r) => (
              <tr key={r.id} className="border-b border-border">
                <td className="px-3 py-2 font-mono text-xs">{r.alumno}</td>
                <td className="px-3 py-2">{r.carrera}</td>
                <td className="px-3 py-2">
                  {r.materia}
                  <span className="ml-2 text-xs text-muted-foreground">{r.materia_codigo}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
