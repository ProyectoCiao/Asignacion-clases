import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { AppShell } from "@/components/app-shell";
import { SortTh } from "@/components/sort-th";
import { listMaterias } from "@/lib/oferta";
import { useSort } from "@/lib/sort";

export const Route = createFileRoute("/materias")({ component: MateriasPage });

function MateriasPage() {
  const q = useQuery({ queryKey: ["materias"], queryFn: () => listMaterias() });
  const rows = q.data ?? [];
  const get = useCallback((r: (typeof rows)[number], key: string) => {
    if (key === "codigo") return r.codigo;
    if (key === "nombre") return r.nombre;
    if (key === "facultad") return r.facultad;
    if (key === "carreras") return r.carreras;
    if (key === "clases") return r.clases;
    return "";
  }, []);
  const sort = useSort(rows, get, "codigo");

  return (
    <AppShell>
      <h2 className="text-lg font-semibold">Materias por facultad y carrera</h2>
      <p className="mt-1 mb-5 max-w-xl text-sm text-muted-foreground">
        El catálogo viene del Excel. Las carreras de esta muestra son provisionales, para atar
        cada materia a planes de estudio.
      </p>
      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs tracking-wide text-muted-foreground uppercase">
            <tr>
              <SortTh label="Código" col="codigo" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Materia" col="nombre" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Facultad" col="facultad" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Carreras" col="carreras" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Clases" col="clases" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
            </tr>
          </thead>
          <tbody>
            {sort.sorted.map((r) => (
              <tr key={r.codigo} className="border-b border-border">
                <td className="px-3 py-2 font-mono text-xs">{r.codigo}</td>
                <td className="px-3 py-2 font-medium">{r.nombre}</td>
                <td className="px-3 py-2">{r.facultad}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{r.carreras || "—"}</td>
                <td className="px-3 py-2 font-mono">{r.clases}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
