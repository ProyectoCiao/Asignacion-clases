import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/pptx")({
  server: {
    handlers: {
      GET: async () => {
        const buf = await readFile(join(process.cwd(), "public/descargas/UADE-asignacion-aulas.pptx"));
        return new Response(buf, {
          headers: {
            "Content-Type":
              "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "Content-Disposition": 'attachment; filename="UADE-asignacion-aulas.pptx"',
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
