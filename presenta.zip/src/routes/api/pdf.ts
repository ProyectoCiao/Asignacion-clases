import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/pdf")({
  server: {
    handlers: {
      GET: async () => {
        const buf = await readFile(join(process.cwd(), "public/descargas/UADE-asignacion-aulas.pdf"));
        return new Response(buf, {
          headers: {
            "Content-Type": "application/pdf",
            "Content-Disposition": 'attachment; filename="UADE-asignacion-aulas.pdf"',
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
