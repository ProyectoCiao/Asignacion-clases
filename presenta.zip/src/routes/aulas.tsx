import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { AppShell } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { SortTh } from "@/components/sort-th";
import { listAulas } from "@/lib/oferta";
import { useSort } from "@/lib/sort";

export const Route = createFileRoute("/aulas")({ component: AulasPage });

function AulasPage() {
  const q = useQuery({ queryKey: ["aulas"], queryFn: () => listAulas() });
  const rows = q.data ?? [];
  const get = useCallback((a: (typeof rows)[number], key: string) => {
    if (key === "sede") return a.sede;
    if (key === "piso") return a.piso ?? Number.POSITIVE_INFINITY;
    if (key === "codigo") return a.codigo;
    if (key === "tipo") return a.tipo_grupo;
    if (key === "total") return a.capacidad_total ?? Number.NEGATIVE_INFINITY;
    if (key === "real") return a.capacidad_real ?? Number.NEGATIVE_INFINITY;
    if (key === "clases") return a.clases;
    return "";
  }, []);
  const sort = useSort(rows, get, "piso");

  return (
    <AppShell>
      <h2 className="text-lg font-semibold">Aulas</h2>
      <p className="mt-1 mb-5 max-w-xl text-sm text-muted-foreground">
        Capacidad total es el tope para asignar. Capacidad real son las sillas del mapa. Tocá
        una columna para ordenar. Remotas no aparecen acá.
      </p>
      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs tracking-wide text-muted-foreground uppercase">
            <tr>
              <SortTh label="Sede" col="sede" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Piso" col="piso" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Aula" col="codigo" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Tipo" col="tipo" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Cap. total" col="total" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Cap. real" col="real" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Clases" col="clases" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
            </tr>
          </thead>
          <tbody>
            {sort.sorted.map((a) => (
              <tr key={a.id} className="border-b border-border">
                <td className="px-3 py-2">{a.sede}</td>
                <td className="px-3 py-2 font-mono">{a.piso ?? "—"}</td>
                <td className="px-3 py-2 font-medium">{a.codigo}</td>
                <td className="px-3 py-2">
                  <Badge>{a.tipo_grupo}</Badge>
                </td>
                <td className="px-3 py-2 font-mono">{a.capacidad_total ?? "—"}</td>
                <td className="px-3 py-2 font-mono">{a.capacidad_real ?? "—"}</td>
                <td className="px-3 py-2 font-mono">{a.clases}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
