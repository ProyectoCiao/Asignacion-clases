import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useState } from "react";
import { createPortal } from "react-dom";
import { AppShell, FieldLabel } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SortTh } from "@/components/sort-th";
import {
  addClase,
  listCatalogos,
  listClases,
  saveOferta,
  sugerirAula,
  type ClaseRow,
  type SugerirResultado,
} from "@/lib/oferta";
import { useSort } from "@/lib/sort";

export const Route = createFileRoute("/")({ component: OfertaPage });

type Draft = {
  aula_id: number | null;
  inscriptos_con_reserva: number;
  turno: "MANANA" | "TARDE" | "NOCHE";
};

type AulaOpt = { id: number; codigo: string; sede: string; capacidad_total: number | null };

const TURNO_ORD: Record<string, number> = { MANANA: 1, TARDE: 2, NOCHE: 3 };

function ofertaValue(
  row: ClaseRow,
  key: string,
  drafts: Record<string, Draft>,
  aulas: AulaOpt[],
) {
  const d = drafts[row.id];
  const aulaId = d ? d.aula_id : row.aula_id;
  const insc = d ? d.inscriptos_con_reserva : row.inscriptos_con_reserva;
  const turno = d ? d.turno : row.turno;
  const aula = aulas.find((a) => a.id === aulaId);
  const cap = aula?.capacidad_total ?? row.capacidad_total;
  const vacias = cap == null ? row.sillas_vacias : cap - insc;
  switch (key) {
    case "nro":
      return row.nro_clase;
    case "materia":
      return row.materia;
    case "dias":
      return `${row.dias} ${row.horario}`;
    case "turno":
      return TURNO_ORD[turno] ?? 9;
    case "insc":
      return insc;
    case "aula":
      return aula?.codigo ?? row.aula_codigo ?? "";
    case "vacias":
      return vacias ?? Number.POSITIVE_INFINITY;
    case "docente":
      return row.docentes;
    default:
      return "";
  }
}

function OfertaPage() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [sede, setSede] = useState("TODAS");
  const [turno, setTurno] = useState("TODOS");
  const [facultad, setFacultad] = useState("TODAS");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);
  const [sug, setSug] = useState<SugerirResultado | null>(null);

  const clases = useQuery({
    queryKey: ["clases", q, sede, turno, facultad],
    queryFn: () => listClases({ data: { q, sede, turno, facultad } }),
  });
  const cat = useQuery({ queryKey: ["catalogos"], queryFn: () => listCatalogos() });
  const dirtyCount = Object.keys(drafts).length;

  function patch(row: ClaseRow, partial: Partial<Draft>) {
    setDrafts((prev) => {
      const current: Draft = prev[row.id] ?? {
        aula_id: row.aula_id,
        inscriptos_con_reserva: row.inscriptos_con_reserva,
        turno: row.turno as Draft["turno"],
      };
      return { ...prev, [row.id]: { ...current, ...partial } };
    });
    setSaveMsg(null);
  }

  const saveMut = useMutation({
    mutationFn: () =>
      saveOferta({
        data: {
          confirmacion: "GRABAR",
          cambios: Object.entries(drafts).map(([id, d]) => ({ id, ...d })),
        },
      }),
    onSuccess: (res) => {
      setDrafts({});
      setConfirmOpen(false);
      setConfirmText("");
      setSaveMsg(
        `Grabadas ${res.filas} filas. Choques de aula: ${res.choques}. Sobrecupos: ${res.sobrecupo}.`,
      );
      void qc.invalidateQueries({ queryKey: ["clases"] });
    },
  });

  const sugMut = useMutation({
    mutationFn: (id: string) => sugerirAula({ data: { clase_id: id } }),
    onSuccess: (res) => setSug(res),
  });

  const rows = clases.data ?? [];
  const aulas = cat.data?.aulas ?? [];
  const getOferta = useCallback(
    (row: ClaseRow, key: string) => ofertaValue(row, key, drafts, aulas),
    [drafts, aulas],
  );
  const sort = useSort(rows, getOferta, "nro");

  return (
    <AppShell>
      <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <p className="max-w-xl text-sm leading-relaxed text-muted-foreground">
          Copia del Excel del cuatrimestre. Filtrá, editá, pedí una sugerencia de aula y grabá con
          confirmación. El docente no se predice acá.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => setAddOpen(true)}>
            Nueva clase
          </Button>
          <Button disabled={dirtyCount === 0} onClick={() => setConfirmOpen(true)}>
            Grabar oferta{dirtyCount ? ` (${dirtyCount})` : ""}
          </Button>
        </div>
      </div>

      {saveMsg ? (
        <p className="mb-3 rounded-md bg-ok-soft px-3 py-2 text-sm text-ok">{saveMsg}</p>
      ) : null}

      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <FieldLabel>Buscar</FieldLabel>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Materia, clase, aula…" />
        </div>
        <div>
          <FieldLabel>Sede</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={sede}
            onChange={(e) => setSede(e.target.value)}
          >
            <option value="TODAS">Todas</option>
            {(cat.data?.sedes ?? []).map((s) => (
              <option key={s.codigo} value={s.codigo}>
                {s.codigo}
              </option>
            ))}
          </select>
        </div>
        <div>
          <FieldLabel>Turno</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={turno}
            onChange={(e) => setTurno(e.target.value)}
          >
            <option value="TODOS">Todos</option>
            <option value="MANANA">Mañana</option>
            <option value="TARDE">Tarde</option>
            <option value="NOCHE">Noche</option>
          </select>
        </div>
        <div>
          <FieldLabel>Facultad</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={facultad}
            onChange={(e) => setFacultad(e.target.value)}
          >
            <option value="TODAS">Todas</option>
            {(cat.data?.facultades ?? []).map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[1200px] table-fixed text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs tracking-wide text-muted-foreground uppercase">
            <tr>
              <SortTh label="Clase" col="nro" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-16" />
              <SortTh label="Materia" col="materia" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Día / horario" col="dias" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-36" />
              <SortTh label="Turno" col="turno" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-28" />
              <SortTh label="Insc." col="insc" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-24" />
              <SortTh label="Aula" col="aula" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-48" />
              <SortTh label="Vacías" col="vacias" active={sort.key} dir={sort.dir} onToggle={sort.toggle} className="w-20" />
              <SortTh label="Docente" col="docente" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <th className="w-28 px-3 py-3 font-medium">Cuadre</th>
            </tr>
          </thead>
          <tbody>
            {clases.isLoading ? (
              <tr>
                <td className="px-3 py-8 text-muted-foreground" colSpan={9}>
                  Cargando oferta…
                </td>
              </tr>
            ) : sort.sorted.length === 0 ? (
              <tr>
                <td className="px-3 py-8 text-muted-foreground" colSpan={9}>
                  No hay filas con ese filtro.
                </td>
              </tr>
            ) : (
              sort.sorted.map((row) => (
                <ClaseRowView
                  key={row.id}
                  row={row}
                  draft={drafts[row.id]}
                  aulas={aulas}
                  onPatch={(p) => patch(row, p)}
                  onSugerir={() => sugMut.mutate(row.id)}
                  sugPending={sugMut.isPending && sugMut.variables === row.id}
                />
              ))
            )}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">{rows.length} clases en vista</p>

      {confirmOpen ? (
        <ConfirmModal
          count={dirtyCount}
          text={confirmText}
          onText={setConfirmText}
          pending={saveMut.isPending}
          error={saveMut.error ? String(saveMut.error) : null}
          onCancel={() => {
            setConfirmOpen(false);
            setConfirmText("");
          }}
          onOk={() => saveMut.mutate()}
        />
      ) : null}

      {sug ? (
        <SugerirModal
          res={sug}
          onClose={() => setSug(null)}
          onUsar={(aula_id) => {
            const row = rows.find((r) => r.id === sug.clase_id);
            if (row) patch(row, { aula_id });
            setSug(null);
          }}
        />
      ) : null}

      {addOpen && cat.data ? (
        <AddClaseModal
          cat={cat.data}
          onClose={() => setAddOpen(false)}
          onCreated={() => {
            setAddOpen(false);
            void qc.invalidateQueries({ queryKey: ["clases"] });
          }}
        />
      ) : null}
    </AppShell>
  );
}

function AulaPicker({
  value,
  options,
  onChange,
}: {
  value: number | null;
  options: AulaOpt[];
  onChange: (id: number | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0, width: 180 });
  const current = options.find((a) => a.id === value);

  function toggle(e: React.MouseEvent<HTMLButtonElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    setPos({ top: r.bottom + 4, left: r.left, width: Math.max(r.width, 180) });
    setOpen((v) => !v);
  }

  const menu = open ? (
    <div
      className="fixed z-50 max-h-48 overflow-y-auto rounded-md border border-border bg-card shadow-md"
      style={{ top: pos.top, left: pos.left, width: pos.width }}
    >
      <button
        type="button"
        className="block w-full px-2 py-2 text-left text-xs hover:bg-muted"
        onClick={() => {
          onChange(null);
          setOpen(false);
        }}
      >
        Sin aula
      </button>
      {options.map((a) => (
        <button
          key={a.id}
          type="button"
          className="block w-full px-2 py-2 text-left text-xs hover:bg-muted"
          onClick={() => {
            onChange(a.id);
            setOpen(false);
          }}
        >
          {a.codigo} ({a.capacidad_total})
        </button>
      ))}
    </div>
  ) : null;

  return (
    <div>
      <button
        type="button"
        className="flex h-9 w-full items-center truncate rounded-md border border-border bg-card px-2 text-left text-xs"
        onClick={toggle}
      >
        {current ? `${current.codigo} (${current.capacidad_total})` : "Sin aula"}
      </button>
      {typeof document !== "undefined" && menu ? createPortal(menu, document.body) : null}
    </div>
  );
}

function ClaseRowView({
  row,
  draft,
  aulas,
  onPatch,
  onSugerir,
  sugPending,
}: {
  row: ClaseRow;
  draft?: Draft;
  aulas: AulaOpt[];
  onPatch: (p: Partial<Draft>) => void;
  onSugerir: () => void;
  sugPending: boolean;
}) {
  const aulaId = draft ? draft.aula_id : row.aula_id;
  const insc = draft ? draft.inscriptos_con_reserva : row.inscriptos_con_reserva;
  const turno = draft ? draft.turno : row.turno;
  const dirty = Boolean(draft);
  const aula = aulas.find((a) => a.id === aulaId);
  const cap = aula?.capacidad_total ?? row.capacidad_total;
  const vacias = cap == null ? row.sillas_vacias : cap - insc;
  const sobrecupo = cap != null && insc > cap;
  const aulasSede = aulas.filter((a) => a.sede === row.sede);

  return (
    <tr className={dirty ? "border-b border-border bg-warn-soft/40" : "border-b border-border"}>
      <td className="px-3 py-2 font-mono text-xs">{row.nro_clase}</td>
      <td className="px-3 py-2">
        <div className="font-medium">{row.materia}</div>
        <div className="text-xs text-muted-foreground">
          {row.materia_codigo} · {row.facultad} · {row.sede}
        </div>
      </td>
      <td className="px-3 py-2 whitespace-nowrap">
        {row.dias}
        <div className="text-xs text-muted-foreground">{row.horario}</div>
      </td>
      <td className="px-3 py-2">
        <select
          className="h-9 w-full rounded-md border border-border bg-card px-2 text-xs"
          value={turno}
          onChange={(e) => onPatch({ turno: e.target.value as Draft["turno"] })}
        >
          <option value="MANANA">Mañana</option>
          <option value="TARDE">Tarde</option>
          <option value="NOCHE">Noche</option>
        </select>
      </td>
      <td className="px-3 py-2">
        <Input
          className="h-9 min-h-9 w-20"
          type="number"
          min={0}
          value={insc}
          onChange={(e) => onPatch({ inscriptos_con_reserva: Number(e.target.value) || 0 })}
        />
      </td>
      <td className="px-3 py-2">
        <AulaPicker value={aulaId} options={aulasSede} onChange={(id) => onPatch({ aula_id: id })} />
      </td>
      <td className="px-3 py-2">
        {sobrecupo ? (
          <Badge tone="danger">{vacias}</Badge>
        ) : vacias != null && vacias <= 8 ? (
          <Badge tone="ok">{vacias}</Badge>
        ) : (
          <span className="font-mono text-xs">{vacias ?? "—"}</span>
        )}
      </td>
      <td className="truncate px-3 py-2 text-xs text-muted-foreground" title={row.docentes}>
        {row.docentes || "—"}
      </td>
      <td className="px-3 py-2">
        <Button size="sm" variant="secondary" onClick={onSugerir} disabled={sugPending}>
          {sugPending ? "…" : "Sugerir"}
        </Button>
      </td>
    </tr>
  );
}

function ConfirmModal({
  count,
  text,
  onText,
  pending,
  error,
  onCancel,
  onOk,
}: {
  count: number;
  text: string;
  onText: (v: string) => void;
  pending: boolean;
  error: string | null;
  onCancel: () => void;
  onOk: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 sm:items-center">
      <div className="w-full max-w-md rounded-lg border border-border bg-card p-5 shadow-lg">
        <h2 className="text-lg font-semibold">Confirmar grabación</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Vas a grabar {count} clase{count === 1 ? "" : "s"} editada{count === 1 ? "" : "s"}. Esto
          pisa la oferta visible para el operador. Escribí <strong>GRABAR</strong> para continuar.
        </p>
        <Input
          className="mt-4"
          value={text}
          onChange={(e) => onText(e.target.value.toUpperCase())}
          placeholder="GRABAR"
          autoFocus
        />
        {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={onCancel}>
            Cancelar
          </Button>
          <Button disabled={text !== "GRABAR" || pending} onClick={onOk}>
            {pending ? "Grabando…" : "Confirmar"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function AddClaseModal({
  cat,
  onClose,
  onCreated,
}: {
  cat: Awaited<ReturnType<typeof listCatalogos>>;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [materia, setMateria] = useState(cat.materias[0]?.codigo ?? "");
  const [sede, setSede] = useState("MONSERRAT");
  const [turno, setTurno] = useState<Draft["turno"]>("MANANA");
  const [dia, setDia] = useState("Lunes");
  const [desde, setDesde] = useState("08:15");
  const [hasta, setHasta] = useState("12:15");
  const [insc, setInsc] = useState(20);
  const [aula, setAula] = useState<number | null>(null);
  const mut = useMutation({
    mutationFn: () =>
      addClase({
        data: {
          materia_codigo: materia,
          sede,
          turno,
          dia,
          horario_desde: desde,
          horario_hasta: hasta,
          inscriptos_con_reserva: insc,
          aula_id: aula,
        },
      }),
    onSuccess: onCreated,
  });
  const aulasSede = useMemo(() => cat.aulas.filter((a) => a.sede === sede), [cat.aulas, sede]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 sm:items-center">
      <div className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-lg">
        <h2 className="text-lg font-semibold">Nueva clase</h2>
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <FieldLabel>Materia</FieldLabel>
            <select
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              value={materia}
              onChange={(e) => setMateria(e.target.value)}
            >
              {cat.materias.map((m) => (
                <option key={m.codigo} value={m.codigo}>
                  {m.nombre} ({m.codigo})
                </option>
              ))}
            </select>
          </div>
          <div>
            <FieldLabel>Sede</FieldLabel>
            <select
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              value={sede}
              onChange={(e) => {
                setSede(e.target.value);
                setAula(null);
              }}
            >
              {cat.sedes.map((s) => (
                <option key={s.codigo} value={s.codigo}>
                  {s.codigo}
                </option>
              ))}
            </select>
          </div>
          <div>
            <FieldLabel>Turno</FieldLabel>
            <select
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              value={turno}
              onChange={(e) => setTurno(e.target.value as Draft["turno"])}
            >
              <option value="MANANA">Mañana</option>
              <option value="TARDE">Tarde</option>
              <option value="NOCHE">Noche</option>
            </select>
          </div>
          <div>
            <FieldLabel>Día</FieldLabel>
            <select
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              value={dia}
              onChange={(e) => setDia(e.target.value)}
            >
              {["Lunes", "Martes", "Miercoles", "Jueves", "Viernes"].map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </div>
          <div>
            <FieldLabel>Desde / hasta</FieldLabel>
            <div className="flex gap-2">
              <Input value={desde} onChange={(e) => setDesde(e.target.value)} />
              <Input value={hasta} onChange={(e) => setHasta(e.target.value)} />
            </div>
          </div>
          <div>
            <FieldLabel>Inscriptos</FieldLabel>
            <Input type="number" min={0} value={insc} onChange={(e) => setInsc(Number(e.target.value) || 0)} />
          </div>
          <div>
            <FieldLabel>Aula</FieldLabel>
            <select
              className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
              value={aula ?? ""}
              onChange={(e) => setAula(e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">Sin asignar</option>
              {aulasSede.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.codigo} ({a.capacidad_total})
                </option>
              ))}
            </select>
          </div>
        </div>
        {mut.error ? <p className="mt-2 text-sm text-danger">{String(mut.error)}</p> : null}
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button disabled={mut.isPending} onClick={() => mut.mutate()}>
            {mut.isPending ? "Agregando…" : "Agregar a la grilla"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function SugerirModal({
  res,
  onClose,
  onUsar,
}: {
  res: SugerirResultado;
  onClose: () => void;
  onUsar: (aula_id: number) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 sm:items-center">
      <div className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-lg border border-border bg-card p-5 shadow-lg">
        <h2 className="text-lg font-semibold">Sugerencia de aula</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Clase {res.nro_clase} · {res.materia} · {res.inscriptos} inscriptos
          {res.aula_actual ? ` · hoy ${res.aula_actual}` : " · sin aula"}
        </p>
        {res.ya_optima ? (
          <p className="mt-3 rounded-md bg-ok-soft px-3 py-2 text-sm text-ok">
            El aula actual ya es la mejor según cupo, choques y sillas vacías.
          </p>
        ) : null}

        {res.recomendada ? (
          <div className="mt-4 rounded-md border border-border p-3">
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Recomendada
            </p>
            <p className="mt-1 font-medium">
              {res.recomendada.codigo}{" "}
              <span className="text-muted-foreground">
                · cap {res.recomendada.capacidad_total} · {res.recomendada.sillas_vacias} vacías
              </span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">{res.recomendada.motivo}</p>
            {!res.ya_optima ? (
              <Button className="mt-3" size="sm" onClick={() => onUsar(res.recomendada!.aula_id)}>
                Usar esta
              </Button>
            ) : null}
          </div>
        ) : (
          <p className="mt-4 text-sm text-danger">No hay aula viable con las reglas duras.</p>
        )}

        {res.alternativas.length > 0 ? (
          <div className="mt-4 space-y-2">
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Alternativas
            </p>
            {res.alternativas.map((a) => (
              <div
                key={a.aula_id}
                className="flex items-start justify-between gap-3 rounded-md border border-border p-3"
              >
                <div>
                  <p className="text-sm font-medium">
                    {a.codigo}{" "}
                    <span className="font-normal text-muted-foreground">
                      · {a.sillas_vacias} vacías
                    </span>
                  </p>
                  <p className="text-xs text-muted-foreground">{a.motivo}</p>
                </div>
                <Button size="sm" variant="secondary" onClick={() => onUsar(a.aula_id)}>
                  Usar
                </Button>
              </div>
            ))}
          </div>
        ) : null}

        {res.bloqueadas.length > 0 ? (
          <div className="mt-4">
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
              No entran
            </p>
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
              {res.bloqueadas.map((b, i) => (
                <li key={`${b.codigo}-${i}`}>
                  <span className="text-foreground">{b.codigo}</span> — {b.motivo}
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="mt-5 flex justify-end">
          <Button variant="secondary" onClick={onClose}>
            Cerrar
          </Button>
        </div>
      </div>
    </div>
  );
}

