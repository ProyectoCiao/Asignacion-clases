import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppShell, FieldLabel } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { listAulas, listMapa, type MapaAula } from "@/lib/oferta";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/mapa")({ component: MapaPage });

const DIAS = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes"] as const;

function MapaPage() {
  const [sede, setSede] = useState("MONSERRAT");
  const [piso, setPiso] = useState(3);
  const [turno, setTurno] = useState<"MANANA" | "TARDE" | "NOCHE">("MANANA");
  const [dia, setDia] = useState<string>("Lunes");
  const [focus, setFocus] = useState<MapaAula | null>(null);

  const aulas = useQuery({ queryKey: ["aulas"], queryFn: () => listAulas() });
  const mapa = useQuery({
    queryKey: ["mapa", sede, piso, turno, dia],
    queryFn: () => listMapa({ data: { sede, piso, turno, dia } }),
  });

  const pisos = useMemo(() => {
    const set = new Set<number>();
    for (const a of aulas.data ?? []) {
      if (a.sede === sede && a.piso != null) set.add(a.piso);
    }
    return [...set].sort((a, b) => a - b);
  }, [aulas.data, sede]);

  const rooms = mapa.data ?? [];
  const ocupadas = rooms.filter((r) => r.clase_nro != null).length;
  const vacias = rooms.reduce((n, r) => {
    const cap = r.capacidad_total ?? 0;
    return n + Math.max(0, cap - r.ocupados);
  }, 0);

  return (
    <AppShell>
      <div className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Mapa de aulas</h2>
          <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted-foreground">
            Vista superior, como un cine: la pizarra adelante, las sillas hacia el fondo. Las
            llenas son alumnos; las vacías, asientos por optimizar.
          </p>
        </div>
        <p className="text-sm tabular-nums text-muted-foreground">
          {ocupadas}/{rooms.length} aulas con clase · {vacias} sillas libres en el piso
        </p>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        <div>
          <FieldLabel>Sede</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={sede}
            onChange={(e) => {
              setSede(e.target.value);
              setFocus(null);
            }}
          >
            <option value="MONSERRAT">Monserrat</option>
            <option value="BELGRANO">Belgrano</option>
            <option value="PINAMAR">Pinamar</option>
          </select>
        </div>
        <div>
          <FieldLabel>Piso</FieldLabel>
          <div className="flex flex-wrap gap-1">
            {pisos.length === 0 ? (
              <span className="text-sm text-muted-foreground">Sin aulas</span>
            ) : (
              pisos.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    setPiso(p);
                    setFocus(null);
                  }}
                  className={cn(
                    "min-h-11 min-w-11 rounded-md px-3 text-sm",
                    p === piso
                      ? "bg-primary text-primary-foreground"
                      : "border border-border bg-card text-foreground hover:bg-muted",
                  )}
                >
                  {p}
                </button>
              ))
            )}
          </div>
        </div>
        <div>
          <FieldLabel>Día</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={dia}
            onChange={(e) => setDia(e.target.value)}
          >
            {DIAS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
        <div>
          <FieldLabel>Turno</FieldLabel>
          <select
            className="h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
            value={turno}
            onChange={(e) => setTurno(e.target.value as typeof turno)}
          >
            <option value="MANANA">Mañana</option>
            <option value="TARDE">Tarde</option>
            <option value="NOCHE">Noche</option>
          </select>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-2">
          <i className="inline-block size-2.5 rounded-[2px] bg-seat-fill" /> Ocupada
        </span>
        <span className="inline-flex items-center gap-2">
          <i className="inline-block size-2.5 rounded-[2px] border border-seat-empty" /> Vacía
        </span>
        <span className="inline-flex items-center gap-2">
          <i className="inline-block size-2.5 rounded-[2px] bg-danger" /> Sobrecupo
        </span>
      </div>

      {mapa.isLoading ? (
        <p className="text-sm text-muted-foreground">Armando el piso…</p>
      ) : rooms.length === 0 ? (
        <p className="rounded-lg border border-border bg-card px-4 py-8 text-sm text-muted-foreground">
          No hay aulas físicas en este piso. Probá otro (Monserrat piso 3 es el de muestra
          inicial).
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rooms.map((room) => (
            <button
              key={room.id}
              type="button"
              onClick={() => setFocus(room)}
              className="rounded-lg border border-border bg-card p-4 text-left transition-[border-color,background-color] duration-150 hover:border-foreground/40"
            >
              <CinemaRoom room={room} compact />
            </button>
          ))}
        </div>
      )}

      {focus ? <CinemaModal room={focus} onClose={() => setFocus(null)} /> : null}
    </AppShell>
  );
}

function seatLayout(n: number) {
  const cols = Math.min(12, Math.max(6, Math.round(Math.sqrt(n * 1.35))));
  const rows = Math.max(1, Math.ceil(n / cols));
  return { cols, rows };
}

function CinemaRoom({ room, compact }: { room: MapaAula; compact?: boolean }) {
  const cap = Math.max(1, room.capacidad_real ?? room.capacidad_total ?? 20);
  const { cols, rows } = seatLayout(cap);
  const ocupados = Math.min(room.ocupados, cap);
  const extra = Math.max(0, room.ocupados - cap);
  const vacias = cap - ocupados;
  const pct = Math.round((ocupados / cap) * 100);

  return (
    <div>
      <div className="mb-3 flex items-start justify-between gap-2">
        <div>
          <p className="font-medium tracking-tight">{room.codigo}</p>
          <p className="text-xs text-muted-foreground">
            {room.tipo_grupo} · {cap} sillas
          </p>
        </div>
        {room.clase_nro ? (
          <Badge tone={extra > 0 ? "danger" : vacias <= 8 ? "ok" : "neutral"}>{pct}%</Badge>
        ) : (
          <Badge>Libre</Badge>
        )}
      </div>

      <div className="theater-stage overflow-hidden px-2 pt-1 pb-4">
        <div
          className="mx-auto mb-2 h-2 w-[82%] rounded-sm bg-screen"
          title="Pizarra"
        />
        <p className="mb-3 text-center text-[10px] tracking-[0.28em] text-muted-foreground uppercase">
          Pizarra
        </p>
        <div className="theater-seats">
          {Array.from({ length: rows }, (_, r) => {
            const start = r * cols;
            const count = Math.min(cols, cap - start);
            const aisleAt = Math.floor(count / 2);
            return (
              <div key={r} className="mb-1.5 flex justify-center gap-1">
                {Array.from({ length: count }, (_, c) => {
                  const i = start + c;
                  const filled = i < ocupados;
                  return (
                    <span key={c} className="contents">
                      {c === aisleAt ? <span className="w-3 sm:w-4" /> : null}
                      <i
                        className={cn(
                          "inline-block rounded-[2px]",
                          compact ? "size-2 sm:size-2.5" : "size-3 sm:size-3.5",
                          filled ? "bg-seat-fill" : "border border-seat-empty bg-transparent",
                        )}
                      />
                    </span>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>

      <p className="text-xs tabular-nums text-muted-foreground">
        {room.clase_nro ? (
          <>
            Clase {room.clase_nro} · {room.materia} · {ocupados}/{cap}
            {extra ? ` · +${extra} sobrecupo` : ` · ${vacias} vacías`}
          </>
        ) : (
          <>Sin clase en este turno · {cap} vacías</>
        )}
      </p>
    </div>
  );
}

function CinemaModal({ room, onClose }: { room: MapaAula; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/50 p-4 sm:items-center">
      <div className="w-full max-w-lg rounded-lg border border-border bg-card p-5 shadow-lg">
        <CinemaRoom room={room} />
        {room.docentes ? (
          <p className="mt-3 text-sm text-muted-foreground">{room.docentes}</p>
        ) : null}
        {room.horario ? (
          <p className="mt-1 text-xs tabular-nums text-muted-foreground">{room.horario}</p>
        ) : null}
        <div className="mt-4 flex justify-end">
          <button
            type="button"
            className="h-11 rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground"
            onClick={onClose}
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}
