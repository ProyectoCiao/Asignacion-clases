import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/proyecto")({ component: ProyectoPage });

const PROMPT_API = `Sos mi par de programación. No sé programar: explicá cada clic.

Abrí / creá un proyecto ASP.NET Core Web API (.NET 9) llamado UadeAulas.Api.
Conectalo a PostgreSQL, base uade_aulas (el schema ya existe: clase, aula, asignacion, sede, materia).

Implementá POST /cuadre/sugerir { "claseId": number } que:
- Tome la clase (sede, día, horario, inscriptos, tipo de aula actual, regimen)
- Liste aulas físicas de la misma sede
- HARD: cupo >= inscriptos; no choque (mismo día y horarios que se pisan); no usar REMOTA/SIN_AULA; si la clase ya está en LAB/TALLER/ARTE no bajarla a AULA común; regimen REMOTO no pide aula
- SOFT: minimizar sillas vacías; conservar el aula actual si sigue sirviendo; no poner comisión chica (<=30) en aula de 70+
- Respuesta: recomendada + 2 alternativas + bloqueadas con motivo
NO asignes docentes ni cambies día/horario. El operador confirma a mano.
Devolvé CORS abierto para http://localhost:4200.`;

const PROMPT_WEB = `Sos mi par de programación. No sé programar: explicá cada clic.

Creá una app Angular (último LTS) llamada uade-aulas-web.
Pantallas: Oferta (grilla filtrable y editable), Mapa cine (aulas piso a piso con sillas ocupadas/vacías), Demanda.
La API está en http://localhost:5080 (UadeAulas.Api).
En cada fila de Oferta hay botón Sugerir que llama POST /cuadre/sugerir y muestra recomendada / alternativas / bloqueadas. "Usar esta" solo cambia el aula en borrador.
Grabar pide escribir GRABAR.
Modo noche: fondo negro, texto claro.
No inventes login. No asignes docentes.`;

function CopyBlock({ label, text }: { label: string; text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="font-medium">{label}</p>
        <Button
          size="sm"
          variant="secondary"
          onClick={async () => {
            await navigator.clipboard.writeText(text);
            setOk(true);
            setTimeout(() => setOk(false), 1500);
          }}
        >
          {ok ? "Copiado" : "Copiar prompt"}
        </Button>
      </div>
      <pre className="max-h-56 overflow-auto whitespace-pre-wrap text-xs leading-relaxed text-muted-foreground">
        {text}
      </pre>
    </div>
  );
}

function ProyectoPage() {
  return (
    <AppShell>
      <h2 className="text-lg font-semibold">Tus dos programas</h2>
      <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
        Esta vista previa ya es el tablero que vas a mostrar. Cuando lo lleves a la PC de UADE,
        se parte en dos: API en Visual Studio Insiders, pantalla en VS Code. Pegá cada prompt en
        el chat de Claude de ese editor. No hace falta que sepas programar.
      </p>

      <div className="mt-5 flex flex-wrap gap-3">
        <a
          href="/descargas/UADE-asignacion-aulas.pptx"
          download
          className="inline-flex min-h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          Bajar PowerPoint (6 diapositivas)
        </a>
        <a
          href="/descargas/UADE-asignacion-aulas.pdf"
          download
          className="inline-flex min-h-11 items-center rounded-md border border-border bg-card px-4 text-sm font-medium"
        >
          Bajar PDF
        </a>
      </div>

      <ol className="mt-6 max-w-2xl list-decimal space-y-3 pl-5 text-sm leading-relaxed">
        <li>
          En <strong>Visual Studio Insiders</strong>: File → New → Project → ASP.NET Core Web API
          → nombre <code>UadeAulas.Api</code>. Abrí el chat de Claude y pegá el prompt de API.
        </li>
        <li>
          En <strong>VS Code</strong>: carpeta nueva <code>uade-aulas-web</code>. Chat de Claude →
          prompt de pantalla.
        </li>
        <li>
          La API habla con la base <code>uade_aulas</code> que ya cargaste. La pantalla habla con
          la API, no con Postgres directo.
        </li>
      </ol>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <CopyBlock label="1. Prompt para Insiders (API)" text={PROMPT_API} />
        <CopyBlock label="2. Prompt para VS Code (pantalla)" text={PROMPT_WEB} />
      </div>

      <p className="mt-6 max-w-2xl text-sm text-muted-foreground">
        Mientras tanto, el botón <strong>Sugerir</strong> de Oferta ya corre esas reglas acá.
        Usalo para la demo. Llevarlo a Insiders/Code es el mismo cerebro, en el stack de la
        universidad.
      </p>
    </AppShell>
  );
}
