import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useCallback } from "react";
import { AppShell } from "@/components/app-shell";
import { SortTh } from "@/components/sort-th";
import { listDocentes } from "@/lib/oferta";
import { useSort } from "@/lib/sort";

export const Route = createFileRoute("/docentes")({ component: DocentesPage });

function DocentesPage() {
  const q = useQuery({ queryKey: ["docentes"], queryFn: () => listDocentes() });
  const rows = q.data ?? [];
  const get = useCallback((r: (typeof rows)[number], key: string) => {
    if (key === "nombre") return r.nombre;
    if (key === "materias") return r.materias;
    if (key === "clases") return r.clases;
    return "";
  }, []);
  const sort = useSort(rows, get, "nombre");

  return (
    <AppShell>
      <h2 className="text-lg font-semibold">Docentes y materias que pueden dar</h2>
      <p className="mt-1 mb-5 max-w-xl text-sm text-muted-foreground">
        Tabla provisoria: se armó con lo que ya dictan en el Excel, más algunos cruces de
        prueba. No reemplaza al motor de los DD. Acá solo se consulta quién podría tomar una
        materia.
      </p>
      <div className="overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[700px] text-left text-sm">
          <thead className="border-b border-border bg-muted text-xs tracking-wide text-muted-foreground uppercase">
            <tr>
              <SortTh label="Docente" col="nombre" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Puede dictar" col="materias" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
              <SortTh label="Clases asignadas" col="clases" active={sort.key} dir={sort.dir} onToggle={sort.toggle} />
            </tr>
          </thead>
          <tbody>
            {sort.sorted.map((r) => (
              <tr key={r.id} className="border-b border-border">
                <td className="px-3 py-2 font-medium">{r.nombre}</td>
                <td className="px-3 py-2 text-xs text-muted-foreground">{r.materias || "—"}</td>
                <td className="px-3 py-2 font-mono">{r.clases}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
