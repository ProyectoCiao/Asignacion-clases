import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/bajar")({ component: BajarPage });

function BajarPage() {
  return (
    <AppShell>
      <h2 className="text-lg font-semibold">Presentación para autoridades</h2>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
        6 diapositivas con capturas del tablero y el flujo de trabajo. Tocá el botón; si el
        navegador no baja, click derecho → Guardar enlace como.
      </p>
      <div className="mt-6 flex max-w-xl flex-col gap-3">
        <a
          href="/api/pptx"
          className="flex min-h-16 items-center justify-between rounded-lg bg-primary px-5 text-left text-primary-foreground"
        >
          <span>
            <span className="block font-medium">PowerPoint</span>
            <span className="block text-sm opacity-80">UADE-asignacion-aulas.pptx · para la reunión</span>
          </span>
          <span className="text-sm">Bajar</span>
        </a>
        <a
          href="/api/pdf"
          className="flex min-h-16 items-center justify-between rounded-lg border border-border bg-card px-5 text-left"
        >
          <span>
            <span className="block font-medium">PDF</span>
            <span className="block text-sm text-muted-foreground">Mismas 6 diapositivas</span>
          </span>
          <span className="text-sm">Bajar</span>
        </a>
      </div>
      <p className="mt-8 text-sm text-muted-foreground">Vista previa del PDF (podés leerlo acá si el botón no baja):</p>
      <iframe
        title="Presentación UADE"
        src="/descargas/UADE-asignacion-aulas.pdf"
        className="mt-3 h-[70vh] w-full rounded-lg border border-border bg-card"
      />
    </AppShell>
  );
}
