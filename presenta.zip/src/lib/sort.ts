import { useMemo, useState } from "react";

export type SortDir = "asc" | "desc";

export function compareValues(a: unknown, b: unknown, dir: SortDir) {
  const mul = dir === "asc" ? 1 : -1;
  if (a == null && b == null) return 0;
  if (a == null || a === "") return 1;
  if (b == null || b === "") return -1;
  if (typeof a === "number" && typeof b === "number") {
    if (Number.isNaN(a) && Number.isNaN(b)) return 0;
    if (Number.isNaN(a)) return 1;
    if (Number.isNaN(b)) return -1;
    return (a - b) * mul;
  }
  return (
    String(a).localeCompare(String(b), "es", { numeric: true, sensitivity: "base" }) * mul
  );
}

export function useSort<T>(rows: T[], getValue: (row: T, key: string) => unknown, defaultKey: string) {
  const [key, setKey] = useState(defaultKey);
  const [dir, setDir] = useState<SortDir>("asc");

  function toggle(next: string) {
    if (next === key) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setKey(next);
      setDir("asc");
    }
  }

  const sorted = useMemo(() => {
    const copy = [...rows];
    copy.sort((a, b) => compareValues(getValue(a, key), getValue(b, key), dir));
    return copy;
  }, [rows, getValue, key, dir]);

  return { sorted, key, dir, toggle };
}
