import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";

export type ClaseRow = {
  id: string;
  nro_clase: number;
  materia_codigo: string;
  materia: string;
  facultad: string;
  sede: string;
  turno: string;
  dias: string;
  horario: string;
  regimen: string;
  inscriptos: number;
  inscriptos_con_reserva: number;
  aula_codigo: string | null;
  aula_id: number | null;
  capacidad_total: number | null;
  sillas_vacias: number | null;
  docentes: string;
  tipo_grupo: string | null;
};

export const listClases = createServerFn({ method: "GET" })
  .validator(
    z.object({
      q: z.string().optional(),
      sede: z.string().optional(),
      turno: z.string().optional(),
      facultad: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    const q = data.q?.trim() ? `%${data.q.trim()}%` : null;
    const sede = data.sede && data.sede !== "TODAS" ? data.sede : null;
    const turno = data.turno && data.turno !== "TODOS" ? data.turno : null;
    const facultad = data.facultad && data.facultad !== "TODAS" ? data.facultad : null;
    return sql.query<ClaseRow>(
      `SELECT
         c.id::text AS id,
         c.nro_clase,
         c.materia_codigo,
         m.nombre AS materia,
         m.facultad,
         s.codigo AS sede,
         c.turno,
         array_to_string(c.dias, ' · ') AS dias,
         to_char(c.horario_desde, 'HH24:MI') || '–' || to_char(c.horario_hasta, 'HH24:MI') AS horario,
         c.regimen,
         c.inscriptos,
         c.inscriptos_con_reserva,
         a.codigo AS aula_codigo,
         a.id AS aula_id,
         a.capacidad_total,
         asg.sillas_vacias,
         a.tipo_grupo,
         COALESCE(
           (SELECT string_agg(d.nombre, ' · ' ORDER BY d.nombre)
            FROM clase_docente cd JOIN docente d ON d.id = cd.docente_id
            WHERE cd.clase_id = c.id),
           ''
         ) AS docentes
       FROM clase c
       JOIN materia m ON m.codigo = c.materia_codigo
       JOIN sede s ON s.id = c.sede_id
       LEFT JOIN asignacion asg ON asg.clase_id = c.id
       LEFT JOIN aula a ON a.id = asg.aula_id
       WHERE ($1::text IS NULL OR m.nombre ILIKE $1 OR c.materia_codigo ILIKE $1
              OR c.nro_clase::text ILIKE $1 OR COALESCE(a.codigo,'') ILIKE $1)
         AND ($2::text IS NULL OR s.codigo = $2)
         AND ($3::text IS NULL OR c.turno = $3)
         AND ($4::text IS NULL OR m.facultad = $4)
       ORDER BY s.codigo, c.turno, c.nro_clase`,
      [q, sede, turno, facultad],
    );
  });

export type MapaAula = {
  id: number;
  sede: string;
  codigo: string;
  tipo_grupo: string;
  piso: number | null;
  capacidad_real: number | null;
  capacidad_total: number | null;
  ocupados: number;
  clase_nro: number | null;
  materia: string | null;
  horario: string | null;
  docentes: string | null;
};

export const listMapa = createServerFn({ method: "GET" })
  .validator(
    z.object({
      sede: z.string(),
      piso: z.number(),
      turno: z.enum(["MANANA", "TARDE", "NOCHE"]),
      dia: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    return sql.query<MapaAula>(
      `SELECT
         a.id,
         s.codigo AS sede,
         a.codigo,
         a.tipo_grupo,
         a.piso,
         a.capacidad_real,
         a.capacidad_total,
         COALESCE(c.inscriptos_con_reserva, 0)::int AS ocupados,
         c.nro_clase AS clase_nro,
         m.nombre AS materia,
         CASE WHEN c.id IS NULL THEN NULL
              ELSE to_char(c.horario_desde, 'HH24:MI') || '–' || to_char(c.horario_hasta, 'HH24:MI')
         END AS horario,
         COALESCE(
           (SELECT string_agg(d.nombre, ' · ' ORDER BY d.nombre)
            FROM clase_docente cd JOIN docente d ON d.id = cd.docente_id
            WHERE cd.clase_id = c.id),
           NULL
         ) AS docentes
       FROM aula a
       JOIN sede s ON s.id = a.sede_id
       LEFT JOIN LATERAL (
         SELECT c0.*
         FROM asignacion asg
         JOIN clase c0 ON c0.id = asg.clase_id
         WHERE asg.aula_id = a.id
           AND c0.turno = $3
           AND $4 = ANY (c0.dias)
         ORDER BY c0.inscriptos_con_reserva DESC
         LIMIT 1
       ) c ON true
       LEFT JOIN materia m ON m.codigo = c.materia_codigo
       WHERE s.codigo = $1
         AND a.piso = $2
         AND a.tipo_grupo NOT IN ('REMOTA','SIN_AULA')
       ORDER BY a.codigo`,
      [data.sede, data.piso, data.turno, data.dia],
    );
  });

export const listAulas = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  return sql<{
    id: number;
    sede: string;
    codigo: string;
    tipo_grupo: string;
    piso: number | null;
    capacidad_real: number | null;
    capacidad_total: number | null;
    clases: number;
  }>`
    SELECT a.id, s.codigo AS sede, a.codigo, a.tipo_grupo, a.piso,
           a.capacidad_real, a.capacidad_total,
           (SELECT count(*)::int FROM asignacion x WHERE x.aula_id = a.id) AS clases
    FROM aula a
    JOIN sede s ON s.id = a.sede_id
    WHERE a.tipo_grupo NOT IN ('REMOTA','SIN_AULA')
    ORDER BY s.codigo, a.piso NULLS LAST, a.codigo
  `;
});

export const listDemanda = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql<{
    materia_codigo: string;
    materia: string;
    facultad: string;
    solicitudes: number;
    clases: number;
    inscriptos_en_clases: number;
    asientos: number | null;
    actualizado_en: string | null;
  }>`
    SELECT
      ds.materia_codigo,
      m.nombre AS materia,
      m.facultad,
      ds.solicitudes,
      (SELECT count(*)::int FROM clase c WHERE c.materia_codigo = ds.materia_codigo AND c.periodo_id = ds.periodo_id) AS clases,
      (SELECT COALESCE(sum(c.inscriptos_con_reserva),0)::int FROM clase c WHERE c.materia_codigo = ds.materia_codigo AND c.periodo_id = ds.periodo_id) AS inscriptos_en_clases,
      (SELECT sum(a.capacidad_total)::int
         FROM clase c
         JOIN asignacion asg ON asg.clase_id = c.id
         JOIN aula a ON a.id = asg.aula_id
        WHERE c.materia_codigo = ds.materia_codigo AND c.periodo_id = ds.periodo_id) AS asientos,
      ds.actualizado_en::text
    FROM demanda_snapshot ds
    JOIN materia m ON m.codigo = ds.materia_codigo
    ORDER BY ds.solicitudes DESC, m.nombre
  `;
  const meta = await sql<{ demanda_actualizada_en: string | null; oferta_grabada_en: string | null }>`
    SELECT demanda_actualizada_en::text, oferta_grabada_en::text FROM oferta_meta WHERE id = 1
  `;
  return { rows, meta: meta[0] ?? { demanda_actualizada_en: null, oferta_grabada_en: null } };
});

export const listInscripciones = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  return sql<{
    id: number;
    alumno: string;
    carrera: string;
    materia_codigo: string;
    materia: string;
  }>`
    SELECT i.id, al.codigo AS alumno, cr.nombre AS carrera,
           i.materia_codigo, m.nombre AS materia
    FROM inscripcion i
    JOIN alumno al ON al.id = i.alumno_id
    JOIN carrera cr ON cr.id = al.carrera_id
    JOIN materia m ON m.codigo = i.materia_codigo
    ORDER BY al.codigo, m.nombre
    LIMIT 400
  `;
});

export const refreshDemanda = createServerFn({ method: "POST" }).handler(async () => {
  const sql = await getSql();
  await sql.query(
    `INSERT INTO demanda_snapshot (periodo_id, materia_codigo, solicitudes, actualizado_en)
     SELECT periodo_id, materia_codigo, count(*)::int, now()
     FROM inscripcion
     GROUP BY periodo_id, materia_codigo
     ON CONFLICT (periodo_id, materia_codigo)
     DO UPDATE SET solicitudes = EXCLUDED.solicitudes, actualizado_en = now()`,
  );
  await sql.query(
    `UPDATE oferta_meta SET demanda_actualizada_en = now() WHERE id = 1`,
  );
  const n = await sql<{ n: number }>`SELECT count(*)::int AS n FROM inscripcion`;
  return { solicitudes: n[0]?.n ?? 0 };
});

export const listMaterias = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  return sql<{
    codigo: string;
    nombre: string;
    facultad: string;
    departamento: string;
    carga_horaria: number | null;
    carreras: string;
    clases: number;
  }>`
    SELECT m.codigo, m.nombre, m.facultad, m.departamento, m.carga_horaria,
           COALESCE((
             SELECT string_agg(c.nombre, ' · ' ORDER BY c.nombre)
             FROM materia_carrera mc JOIN carrera c ON c.id = mc.carrera_id
             WHERE mc.materia_codigo = m.codigo
           ), '') AS carreras,
           (SELECT count(*)::int FROM clase x WHERE x.materia_codigo = m.codigo) AS clases
    FROM materia m
    ORDER BY m.facultad, m.nombre
  `;
});

export const listDocentes = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  return sql<{
    id: number;
    nombre: string;
    materias: string;
    clases: number;
  }>`
    SELECT d.id, d.nombre,
           COALESCE((
             SELECT string_agg(m.nombre, ' · ' ORDER BY m.nombre)
             FROM docente_materia dm JOIN materia m ON m.codigo = dm.materia_codigo
             WHERE dm.docente_id = d.id
           ), '') AS materias,
           (SELECT count(*)::int FROM clase_docente cd WHERE cd.docente_id = d.id) AS clases
    FROM docente d
    ORDER BY d.nombre
  `;
});

export const listCatalogos = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const sedes = await sql<{ codigo: string; nombre: string }>`SELECT codigo, nombre FROM sede ORDER BY id`;
  const facultades = await sql<{ facultad: string }>`SELECT DISTINCT facultad FROM materia WHERE facultad IS NOT NULL ORDER BY 1`;
  const aulas = await sql<{ id: number; codigo: string; sede: string; capacidad_total: number | null }>`
    SELECT a.id, a.codigo, s.codigo AS sede, a.capacidad_total
    FROM aula a JOIN sede s ON s.id = a.sede_id
    WHERE a.tipo_grupo NOT IN ('REMOTA','SIN_AULA')
    ORDER BY a.codigo
  `;
  const materias = await sql<{ codigo: string; nombre: string }>`SELECT codigo, nombre FROM materia ORDER BY nombre`;
  return {
    sedes,
    facultades: facultades.map((f) => f.facultad),
    aulas,
    materias,
  };
});

const saveSchema = z.object({
  confirmacion: z.literal("GRABAR"),
  cambios: z.array(
    z.object({
      id: z.string(),
      aula_id: z.number().nullable(),
      inscriptos_con_reserva: z.number().int().nonnegative(),
      turno: z.enum(["MANANA", "TARDE", "NOCHE"]),
    }),
  ),
});

export const saveOferta = createServerFn({ method: "POST" })
  .validator(saveSchema)
  .handler(async ({ data }) => {
    const sql = await getSql();
    let choques = 0;
    for (const c of data.cambios) {
      await sql.query(
        `UPDATE clase SET inscriptos_con_reserva = $2, inscriptos = $2, turno = $3 WHERE id = $1`,
        [c.id, c.inscriptos_con_reserva, c.turno],
      );
      if (c.aula_id == null) {
        await sql.query(
          `UPDATE asignacion SET aula_id = NULL, origen = 'MANUAL', sillas_vacias = NULL WHERE clase_id = $1`,
          [c.id],
        );
      } else {
        await sql.query(
          `UPDATE asignacion AS asg SET
             aula_id = $2,
             origen = 'MANUAL',
             sillas_vacias = (SELECT capacidad_total FROM aula WHERE id = $2)
               - (SELECT inscriptos_con_reserva FROM clase WHERE id = $1)
           WHERE asg.clase_id = $1`,
          [c.id, c.aula_id],
        );
      }
    }
    const overlaps = await sql<{ n: number }>`
      SELECT count(*)::int AS n FROM (
        SELECT a1.aula_id
        FROM asignacion a1
        JOIN clase c1 ON c1.id = a1.clase_id
        JOIN asignacion a2 ON a2.aula_id = a1.aula_id AND a2.clase_id > a1.clase_id
        JOIN clase c2 ON c2.id = a2.clase_id
        WHERE a1.aula_id IS NOT NULL
          AND c1.turno = c2.turno
          AND c1.dias && c2.dias
          AND c1.horario_desde < c2.horario_hasta
          AND c2.horario_desde < c1.horario_hasta
      ) x
    `;
    choques = overlaps[0]?.n ?? 0;
    const sobrecupo = await sql<{ n: number }>`
      SELECT count(*)::int AS n
      FROM asignacion asg
      JOIN clase c ON c.id = asg.clase_id
      JOIN aula a ON a.id = asg.aula_id
      WHERE c.inscriptos_con_reserva > a.capacidad_total
    `;
    await sql.query(`UPDATE oferta_meta SET oferta_grabada_en = now() WHERE id = 1`, []);
    return {
      filas: data.cambios.length,
      choques,
      sobrecupo: sobrecupo[0]?.n ?? 0,
    };
  });

export const addClase = createServerFn({ method: "POST" })
  .validator(
    z.object({
      materia_codigo: z.string(),
      sede: z.string(),
      turno: z.enum(["MANANA", "TARDE", "NOCHE"]),
      dia: z.string(),
      horario_desde: z.string(),
      horario_hasta: z.string(),
      inscriptos_con_reserva: z.number().int().nonnegative(),
      aula_id: z.number().nullable(),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    const next = await sql<{ id: string; nro: number }>`
      SELECT (COALESCE(max(id), 0) + 1)::text AS id, COALESCE(max(nro_clase), 1000) + 1 AS nro FROM clase
    `;
    const sede = await sql<{ id: number }>`SELECT id FROM sede WHERE codigo = ${data.sede}`;
    if (!sede[0]) throw new Error("Sede desconocida");
    const id = next[0].id;
    const nro = next[0].nro;
    await sql.query(
      `INSERT INTO clase (
         id, nro_clase, periodo_id, sede_id, materia_codigo, turno,
         horario_desde, horario_hasta, dias, regimen, idioma, modalidad,
         inscriptos, inscriptos_con_reserva, packs
       ) VALUES ($1,$2,1,$3,$4,$5,$6,$7,ARRAY[$8]::text[],'SEMANAL','ESPAÑOL','REGULAR',$9,$9,'{}')`,
      [
        id,
        nro,
        sede[0].id,
        data.materia_codigo,
        data.turno,
        data.horario_desde,
        data.horario_hasta,
        data.dia,
        data.inscriptos_con_reserva,
      ],
    );
    let vacias: number | null = null;
    if (data.aula_id) {
      const cap = await sql<{ capacidad_total: number }>`SELECT capacidad_total FROM aula WHERE id = ${data.aula_id}`;
      vacias = (cap[0]?.capacidad_total ?? 0) - data.inscriptos_con_reserva;
    }
    await sql.query(
      `INSERT INTO asignacion (clase_id, aula_id, origen, sillas_vacias) VALUES ($1,$2,'MANUAL',$3)`,
      [id, data.aula_id, vacias],
    );
    return { id, nro };
  });

export type SugerenciaAula = {
  aula_id: number;
  codigo: string;
  tipo_grupo: string;
  capacidad_total: number;
  sillas_vacias: number;
  piso: number | null;
  motivo: string;
};

export type SugerirResultado = {
  clase_id: string;
  nro_clase: number;
  materia: string;
  inscriptos: number;
  aula_actual: string | null;
  regimen: string;
  recomendada: SugerenciaAula | null;
  alternativas: SugerenciaAula[];
  bloqueadas: { codigo: string; motivo: string }[];
  ya_optima: boolean;
};

function toMin(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function diasOverlap(a: string[], b: string[]) {
  return a.some((d) => b.includes(d));
}

export const sugerirAula = createServerFn({ method: "POST" })
  .validator(z.object({ clase_id: z.string() }))
  .handler(async ({ data }): Promise<SugerirResultado> => {
    const sql = await getSql();
    const clase = await sql.query<{
      id: string;
      nro_clase: number;
      materia: string;
      sede: string;
      turno: string;
      dias: string;
      desde: string;
      hasta: string;
      inscriptos: number;
      regimen: string;
      aula_id: number | null;
      aula_codigo: string | null;
      tipo_actual: string | null;
    }>(
      `SELECT c.id::text AS id, c.nro_clase, m.nombre AS materia, s.codigo AS sede, c.turno,
              array_to_string(c.dias, ',') AS dias,
              to_char(c.horario_desde, 'HH24:MI') AS desde,
              to_char(c.horario_hasta, 'HH24:MI') AS hasta,
              c.inscriptos_con_reserva AS inscriptos,
              c.regimen,
              asg.aula_id,
              a.codigo AS aula_codigo,
              a.tipo_grupo AS tipo_actual
       FROM clase c
       JOIN materia m ON m.codigo = c.materia_codigo
       JOIN sede s ON s.id = c.sede_id
       LEFT JOIN asignacion asg ON asg.clase_id = c.id
       LEFT JOIN aula a ON a.id = asg.aula_id
       WHERE c.id::text = $1`,
      [data.clase_id],
    );
    const c = clase[0];
    if (!c) throw new Error("Clase no encontrada");

    const empty: SugerirResultado = {
      clase_id: c.id,
      nro_clase: c.nro_clase,
      materia: c.materia,
      inscriptos: c.inscriptos,
      aula_actual: c.aula_codigo,
      regimen: c.regimen,
      recomendada: null,
      alternativas: [],
      bloqueadas: [],
      ya_optima: false,
    };

    if (c.regimen === "REMOTO") {
      return { ...empty, bloqueadas: [{ codigo: "—", motivo: "Régimen remoto: no ocupa aula física" }] };
    }

    const aulas = await sql.query<{
      id: number;
      codigo: string;
      tipo_grupo: string;
      capacidad_total: number | null;
      piso: number | null;
    }>(
      `SELECT a.id, a.codigo, a.tipo_grupo, a.capacidad_total, a.piso
       FROM aula a JOIN sede s ON s.id = a.sede_id
       WHERE s.codigo = $1 AND a.activa = true AND a.tipo_grupo NOT IN ('REMOTA','SIN_AULA')`,
      [c.sede],
    );

    const ocup = await sql.query<{
      aula_id: number;
      clase_id: string;
      nro_clase: number;
      dias: string;
      desde: string;
      hasta: string;
    }>(
      `SELECT asg.aula_id, c2.id::text AS clase_id, c2.nro_clase,
              array_to_string(c2.dias, ',') AS dias,
              to_char(c2.horario_desde, 'HH24:MI') AS desde,
              to_char(c2.horario_hasta, 'HH24:MI') AS hasta
       FROM asignacion asg
       JOIN clase c2 ON c2.id = asg.clase_id
       JOIN aula a ON a.id = asg.aula_id
       JOIN sede s ON s.id = a.sede_id
       WHERE s.codigo = $1 AND asg.aula_id IS NOT NULL AND c2.id::text <> $2`,
      [c.sede, c.id],
    );

    const need = c.dias.split(",").filter(Boolean);
    const t0 = toMin(c.desde);
    const t1 = toMin(c.hasta);
    const especial = c.tipo_actual === "LAB" || c.tipo_actual === "TALLER" || c.tipo_actual === "ARTE";

    const bloqueadas: { codigo: string; motivo: string }[] = [];
    const viable: SugerenciaAula[] = [];

    for (const a of aulas) {
      const cap = a.capacidad_total ?? 0;
      if (cap < c.inscriptos) {
        bloqueadas.push({ codigo: a.codigo, motivo: `Cupo ${cap} < ${c.inscriptos} inscriptos` });
        continue;
      }
      if (especial && a.tipo_grupo !== c.tipo_actual) {
        bloqueadas.push({ codigo: a.codigo, motivo: `La clase ya usa ${c.tipo_actual}; no bajar a ${a.tipo_grupo}` });
        continue;
      }
      const choque = ocup.find((o) => {
        if (o.aula_id !== a.id) return false;
        const od = o.dias.split(",").filter(Boolean);
        if (!diasOverlap(need, od)) return false;
        const o0 = toMin(o.desde);
        const o1 = toMin(o.hasta);
        return t0 < o1 && o0 < t1;
      });
      if (choque) {
        bloqueadas.push({
          codigo: a.codigo,
          motivo: `Choque con clase ${choque.nro_clase} (${choque.desde}–${choque.hasta})`,
        });
        continue;
      }

      const vacias = cap - c.inscriptos;
      let costo = vacias;
      const motivos: string[] = [`${vacias} sillas vacías`];
      if (c.aula_id === a.id) {
        costo -= 4;
        motivos.push("ya asignada (se conserva si sigue sirviendo)");
      }
      if (c.tipo_actual && a.tipo_grupo === c.tipo_actual) {
        costo -= 2;
        motivos.push(`mismo tipo ${a.tipo_grupo}`);
      }
      if (cap >= 70 && c.inscriptos <= 30) {
        costo += 18;
        motivos.push("aula grande para comisión chica");
      }
      viable.push({
        aula_id: a.id,
        codigo: a.codigo,
        tipo_grupo: a.tipo_grupo,
        capacidad_total: cap,
        sillas_vacias: vacias,
        piso: a.piso,
        motivo: motivos.join(" · ") + ` (puntaje ${costo})`,
      });
      (viable[viable.length - 1] as SugerenciaAula & { costo?: number }).costo = costo;
    }

    viable.sort((x, y) => {
      const cx = (x as SugerenciaAula & { costo?: number }).costo ?? x.sillas_vacias;
      const cy = (y as SugerenciaAula & { costo?: number }).costo ?? y.sillas_vacias;
      if (cx !== cy) return cx - cy;
      return x.sillas_vacias - y.sillas_vacias;
    });

    const recomendada = viable[0] ?? null;
    const ya_optima = Boolean(recomendada && c.aula_id === recomendada.aula_id);

    return {
      ...empty,
      recomendada,
      alternativas: viable.slice(1, 3),
      bloqueadas: bloqueadas.slice(0, 8),
      ya_optima,
    };
  });
