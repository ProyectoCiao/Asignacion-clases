---
name: uade-asignacion-aulas
description: Asigna comisiones UADE a aulas respetando capacidad, turno, horario, tipo de espacio y docentes. Usar al interpretar el Excel de clases, sugerir aula, detectar sillas vacias, modelar Postgres o armar el MVP de 3 aulas Monserrat.
---

# UADE — Asignación de aulas

Trabajá con el lenguaje del Excel real de UADE. No inventes columnas. No asignes alumno por alumno. La unidad es la **clase** (comisión).

## Unidad de trabajo

Una **clase** es una fila del Excel. Lleva materia, docentes, inscriptos, turno, horario, día, aula principal y packs de carrera.

El MVP no coloca estudiantes. Coloca la clase completa en un aula + franja.

## Alcance de este skill

- Sede del producto: Campus Buenos Aires — Monserrat (Belgrano después). Pinamar queda fuera del MVP.
- Primer corte visual: **un piso, 3 aulas** de capacidad distinta.
- Datos de prototipo pueden ser inventados; nombres de aulas y columnas deben parecerse al Excel.

Cuando haga falta detalle, leer:
- `references/glosario.md` — facultades, tipos de aula, códigos
- `references/modelo-datos.md` — tablas Postgres
- `references/reglas.md` — hard / soft constraints y puntaje

## Qué hacer con un pedido en castellano

Ejemplos de pedido:
- "pasame Marketing I noche al aula más chica que entre"
- "esta clase tiene 32 inscriptos, qué aula del piso 3 uso"
- "mostrame sillas vacías del lunes mañana"

Pasos:
1. Identificar la **clase** (número de clase, materia, turno, día, horario, inscriptos).
2. Si falta un dato bloqueante (inscriptos, horario o día), pedirlo. No inventar inscriptos.
3. Filtrar aulas candidatas con reglas HARD de `references/reglas.md`.
4. Ordenar por puntaje SOFT (menos sillas vacías primero).
5. Devolver 1 recomendada + 2 alternativas, con sillas vacías y motivo en una línea.

Formato de respuesta de asignación:

```
Clase 1015 | MARKETING | Lunes 08:15-12:15 | 29 insc.
Recomendada: 632-AULA (cap 30) — 1 silla vacía
Alt 1: ...
Alt 2: ...
Bloqueadas: ... (motivo)
```

## Reglas que no se discuten

1. `inscriptos_con_reserva <= capacidad_total` del aula. Si no entra, no va.
2. Un aula no admite dos clases que se pisen en día + horario.
3. Un docente no puede estar en dos aulas que se pisen.
4. Tipo de espacio: un TALLER / LAB / ARTE / FIN LAB no se usa como aula genérica si la materia pide ese tipo.
5. `CLASE REMOTA` y aula `-` no ocupan mapa físico.
6. No cuestionar por qué existe la clase. Solo ubicarla.

## Capacidades

En el Excel hay dos números:
- **Capacidad Real** — sillas físicas / lo que informa infraestructura.
- **Capacidad Total** — tope que usa asignación (a veces menor).

Para validar cupo usá **Capacidad Total**. Para el mapa tipo cine usá **Capacidad Real** (sillas dibujadas).

## MVP de 3 aulas (piso inventado Monserrat)

Piso 3, misma planta:

| codigo        | tipo    | cap_real | cap_total |
|---------------|---------|----------|-----------|
| 304-AULA      | AULA    | 32       | 30        |
| 333-AULA      | AULA    | 70       | 65        |
| 335-HÍBRIDA   | HÍBRIDA | 48       | 45        |

Tres tamaños a propósito: chica / grande / mediana híbrida.

## Cómo puntuar sin tokens (motor local)

```
viable = cap_total >= inscriptos
        AND tipo compatible
        AND sin choque de aula
        AND sin choque de docente

score = (cap_total - inscriptos)           # menor es mejor
      + 5 si el tipo es más específico que AULA y la materia lo pide
      + 3 si es la misma aula que el cuatri anterior
```

Elegir el viable de menor score. Empate: conservar aula del período anterior.

## Qué no hacer

- No diseñar chat para alumnos o docentes.
- No conectar Guaraní/SIU en el MVP.
- No entrenar ML con esta muestra: 233 filas no alcanzan y el Excel ya trae la asignación hecha.
- No homogeneizar horarios. Los bloques reales NO son todos iguales (07:45-11:45, 08:15-12:15, 18:30-21:30, 18:30-22:00 conviven).
