---
description: Glosario del Excel de clases UADE. Leer al interpretar columnas, facultades, tipos de aula o códigos.
---

# Glosario UADE (según muestra 1er cuatri 2026)

## Columnas del Excel

| Columna | Significado |
|---|---|
| Facultad | FACE, FACO, FAIN, FADI, FAJU, FASA, FARU |
| Departamento | Código interno del depto (DECOX, DEINI, DEFUD...) |
| Sede | MONSERRAT, PINAMAR. Producto = Monserrat + Belgrano |
| Ciclo | Año lectivo (2026) |
| Periodo | 1er CUATR / 2do CUATR |
| Clase | Número de comisión en el período (no es único histórico; el único estable es Id) |
| Desde / Hasta | Fechas de dictado (en el Excel suelen venir como serial de Excel) |
| Turno | MAÑANA, TARDE, NOCHE |
| Horario | Rango real, no grilla fija |
| Tipo | Casi siempre ASIGNATURA |
| CódigoMateria | Ej. 1.2.001 |
| Materia | Nombre. Puede estar cortado |
| CargaHorariaMateria | Horas de la materia en el período |
| Modalidad | REGULAR |
| Idioma | ESPAÑOL / INGLÉS |
| Aula Principal | `{codigo}-{TIPO}` o `CLASE REMOTA` o `-` |
| Capacidad Real | Sillas físicas |
| Capacidad Total | Tope de asignación |
| Packs Asociados | Códigos de plan/carrera que alimentan la comisión. Varios separados por coma |
| Inscriptos ... Sin Considerar Reservas | Confirmados |
| Inscriptos ... Con Reserva | Usar este para dimensionar el aula |
| Docentes | Apellido, Nombre separados por ` - ` |
| Dias De Cursada | Lunes, Martes... o `Lunes - Miercoles` |
| Régimen | SEMANAL, ALEKS (matemática adaptativa), REMOTO |
| Id | Identificador de la oferta/clase en el sistema origen |
| Total Asignado + roles | Horas docentes por cargo (Titular, Adjunto, JTP...) |

## Facultades vistas

- FACE — Ciencias Económicas
- FACO — Comunicación
- FAIN — Ingeniería
- FADI — Diseño
- FAJU — Jurídicas
- FASA — Salud
- FARU — Arquitectura

## Cómo se lee un aula

Patrones:
- `333-AULA` — aula estándar, código 333 (el primer dígito suele ser piso; 3xx = piso 3)
- `s234-AULA` — subsuelo
- `635-HÍBRIDA` — aula con equipo de híbrida
- `065-FIN LAB` — lab de finanzas
- `165-LAB MULTIPLATAFORMA-MAC`
- `663-LAB DE INFORMÁTICA`
- `473-ARTE` / `S172-ARTE`
- `P005-HÍBRIDA` — Pinamar (prefijo P)
- `CLASE REMOTA` — no va al mapa

## Hallazgos de la muestra (233 filas)

- Monserrat 218 / Pinamar 15
- Tarde 88, Mañana 80, Noche 65
- 172 aulas distintas en 233 filas
- ~15 sillas vacías promedio por clase con aula
- 0 sobrecupo en la muestra
- 0 choque aula+día+horario en la muestra (el Excel ya viene "limpio")
- Horarios no unificados: conviven 07:45-11:45 y 08:15-12:15 a la mañana
