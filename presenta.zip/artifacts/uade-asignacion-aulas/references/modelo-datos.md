---
description: Modelo Postgres del MVP y mapeo 1 a 1 con el Excel de clases UADE.
---

# Modelo de datos MVP

Normalizar el Excel. No guardar una sola tabla ancha como sistema.

## Tablas

### sede
`id, codigo, nombre`  
Ej. MONSERRAT, BELGRANO

### edificio / piso
Para el mapa cine. MVP: un edificio Monserrat, piso 3.

### aula
```
id
sede_id
piso
codigo          -- 333-AULA
tipo            -- AULA | HIBRIDA | LAB | TALLER | ARTE | REMOTA
capacidad_real
capacidad_total
activa
```

### materia
`codigo, nombre, carga_horaria, facultad, departamento`

### persona_docente
`id, apellido_nombre`  
Parsear la columna Docentes por ` - `.

### clase
Es la fila del Excel.
```
id                  -- Id del Excel
nro_clase           -- columna Clase
ciclo
periodo
sede_id
materia_codigo
turno               -- MANANA | TARDE | NOCHE
horario_desde       -- time
horario_hasta
dias                -- text[]  {'Lunes'} o {'Lunes','Miercoles'}
regimen             -- SEMANAL | ALEKS | REMOTO
idioma
inscriptos
inscriptos_con_reserva
packs               -- text[]
```

### clase_docente
`clase_id, docente_id, rol`  
El rol (titular, adjunto...) se puede inferir después; al inicio basta el nombre.

### asignacion
```
id
clase_id
aula_id             -- null si REMOTO o sin aula
origen              -- HEREDADA | MANUAL | SUGERIDA
periodo_origen      -- si vino del cuatri anterior
```

## Relación con el Excel

Importar 1 fila = 1 `clase` + N `clase_docente` + 1 `asignacion` si hay aula.

`Desde`/`Hasta` son seriales Excel. Convertir:  
`date = 1899-12-30 + serial días` (con el leap bug de Excel).  
En la muestra, 46090 ≈ 2026-03-09.

## MVP seed — 3 aulas piso 3

Ver `/workspace/artifacts/mvp-3-aulas/schema.sql`.
