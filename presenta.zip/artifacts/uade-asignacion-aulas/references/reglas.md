---
description: Restricciones hard y soft para sugerir aula. Leer antes de puntuar una asignación.
---

# Reglas de asignación

## HARD — si falla, la aula queda fuera

1. Cupo: `inscriptos_con_reserva <= aula.capacidad_total`
2. Sede: la clase Monserrat no va a Belgrano (ni Pinamar)
3. Solape de aula: mismo `aula` + día en común + horarios que se pisan
4. Solape de docente: mismo docente + día en común + horarios que se pisan
5. Régimen REMOTO o aula `CLASE REMOTA` → no entra al mapa
6. Tipo especial: si la materia ya está en LAB/TALLER/ARTE/FIN LAB, no bajarla a AULA común salvo pedido explícito
7. Turno: no mover una clase de NOCHE a MAÑANA como "optimización"

Pisa horario si `desde_a < hasta_b AND desde_b < hasta_a`.

## SOFT — desempate

Orden de menor a mayor costo:

1. Sillas vacías = `capacidad_total - inscriptos_con_reserva` (minimizar)
2. Conservar aula del cuatri anterior
3. Preferir el tipo más específico que la clase ya usa (HÍBRIDA si ya era híbrida)
4. Evitar subir una comisión chica a un aula de 70+ si hay una de 30-45 libre

## Qué NO optimizar en el MVP

- Recorrido del alumno entre edificios
- Preferencias del docente
- Correlativas
- Packs / planes de carrera (se guardan, no se usan para el mapa)
- Carga horaria por cargo docente

## Pedido en castellano — slots a extraer

| Dato | Ejemplos |
|---|---|
| nro_clase | "la 1015", "clase 1321" |
| materia | "Marketing", "Introducción al Derecho" |
| turno | mañana / tarde / noche |
| día | lunes |
| inscriptos | "tiene 29" |
| aula actual | "sacala de la 448" |
| intención | más chica / más grande / híbrida / lab |

Si hay materia + turno pero varias comisiones, listarlas y no elegir a ciegas.
