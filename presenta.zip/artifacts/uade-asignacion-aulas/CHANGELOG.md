# Changelog
## 2026-09-10
- Skill inicial a partir del Excel recortado de clases 1er cuatri 2026
- Alcance MVP: Monserrat, 1 piso, 3 aulas
- Reglas hard/soft y mapeo de columnas reales
