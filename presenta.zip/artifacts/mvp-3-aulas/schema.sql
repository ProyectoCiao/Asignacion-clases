-- MVP UADE: 1 piso, 3 aulas Monserrat
-- Prototipo. Capacidades inventadas sobre códigos reales.

CREATE TABLE sede (
  id        smallserial PRIMARY KEY,
  codigo    text UNIQUE NOT NULL,
  nombre    text NOT NULL
);

CREATE TABLE aula (
  id               smallserial PRIMARY KEY,
  sede_id          smallint NOT NULL REFERENCES sede(id),
  piso             smallint NOT NULL,
  codigo           text UNIQUE NOT NULL,
  tipo             text NOT NULL CHECK (tipo IN ('AULA','HIBRIDA','LAB','TALLER','ARTE','REMOTA')),
  capacidad_real   int NOT NULL,
  capacidad_total  int NOT NULL,
  activa           boolean NOT NULL DEFAULT true
);

CREATE TABLE materia (
  codigo           text PRIMARY KEY,
  nombre           text NOT NULL,
  facultad         text,
  departamento     text,
  carga_horaria    int
);

CREATE TABLE docente (
  id               serial PRIMARY KEY,
  nombre           text UNIQUE NOT NULL
);

CREATE TABLE clase (
  id                       bigint PRIMARY KEY,
  nro_clase                int NOT NULL,
  ciclo                    int NOT NULL,
  periodo                  text NOT NULL,
  sede_id                  smallint NOT NULL REFERENCES sede(id),
  materia_codigo           text REFERENCES materia(codigo),
  turno                    text NOT NULL CHECK (turno IN ('MANANA','TARDE','NOCHE')),
  horario_desde            time NOT NULL,
  horario_hasta            time NOT NULL,
  dias                     text[] NOT NULL,
  regimen                  text NOT NULL DEFAULT 'SEMANAL',
  idioma                   text,
  inscriptos               int NOT NULL DEFAULT 0,
  inscriptos_con_reserva   int NOT NULL DEFAULT 0,
  packs                    text[]
);

CREATE TABLE clase_docente (
  clase_id   bigint REFERENCES clase(id),
  docente_id int REFERENCES docente(id),
  PRIMARY KEY (clase_id, docente_id)
);

CREATE TABLE asignacion (
  id         serial PRIMARY KEY,
  clase_id   bigint NOT NULL REFERENCES clase(id),
  aula_id    int REFERENCES aula(id),
  origen     text NOT NULL DEFAULT 'MANUAL'
);

INSERT INTO sede (codigo, nombre) VALUES
  ('MONSERRAT', 'Campus Buenos Aires — Monserrat'),
  ('BELGRANO',  'UADE Belgrano');

INSERT INTO aula (sede_id, piso, codigo, tipo, capacidad_real, capacidad_total) VALUES
  (1, 3, '304-AULA',    'AULA',    32, 30),
  (1, 3, '333-AULA',    'AULA',    70, 65),
  (1, 3, '335-HÍBRIDA', 'HIBRIDA', 48, 45);

INSERT INTO materia (codigo, nombre, facultad, departamento, carga_horaria) VALUES
  ('1.2.102', 'GESTIÓN EMPRESARIAL',          'FACE', 'DEBIZ', 68),
  ('1.2.001', 'MARKETING',                    'FACE', 'DECOX', 68),
  ('2.3.001', 'INTRODUCCIÓN AL DERECHO',      'FAJU', 'DEFUD', 68);

INSERT INTO docente (nombre) VALUES
  ('Belocopitow, Pablo Federico'),
  ('Nadal, Natalia Elisa'),
  ('Valsi, Melisa Alejandra'),
  ('Jessenne, Anabel Roxana'),
  ('Ottati Paz, Juan Manuel'),
  ('Guerra, Claudia Lorena');

-- Filas reales del Excel recortado (cupos que cierran con las 3 aulas).
-- 1015: 29 insc. Martes mañana  → entra en 304 (30)
-- 1080: 33 insc. Lunes mañana   → entra en 335-HÍBRIDA (45)
-- 1045: 63 insc. Lunes mañana   → solo entra en 333 (65)
INSERT INTO clase (
  id, nro_clase, ciclo, periodo, sede_id, materia_codigo,
  turno, horario_desde, horario_hasta, dias, regimen, idioma,
  inscriptos, inscriptos_con_reserva, packs
) VALUES
  (748607, 1015, 2026, '1er CUATR', 1, '1.2.102',
   'MANANA', '08:15', '12:15', ARRAY['Martes'], 'SEMANAL', 'INGLÉS',
   29, 29, ARRAY['1M14124A']),
  (748753, 1080, 2026, '1er CUATR', 1, '1.2.001',
   'MANANA', '08:15', '12:15', ARRAY['Lunes'], 'SEMANAL', 'ESPAÑOL',
   33, 33, ARRAY['1M22224C']),
  (748640, 1045, 2026, '1er CUATR', 1, '2.3.001',
   'MANANA', '08:15', '12:15', ARRAY['Lunes'], 'SEMANAL', 'ESPAÑOL',
   63, 63, ARRAY['1M1924B']);

INSERT INTO asignacion (clase_id, aula_id, origen) VALUES
  (748607, 1, 'SUGERIDA'),
  (748753, 3, 'SUGERIDA'),
  (748640, 2, 'SUGERIDA');
