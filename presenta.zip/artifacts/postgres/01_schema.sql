-- UADE asignación de aulas — schema alineado a 4 skills
-- 1 uade-demanda   2 uade-aulas   3 uade-oferta   4 uade-cuadre
-- Docente y día/hora son INPUT (sistema de DD / oferta académica). Este modelo no predice docentes.

BEGIN;

CREATE TABLE sede (
  id      smallserial PRIMARY KEY,
  codigo  text UNIQUE NOT NULL,
  nombre  text NOT NULL
);

-- Skill 2: inventario de espacios
CREATE TABLE aula (
  id               serial PRIMARY KEY,
  sede_id          smallint NOT NULL REFERENCES sede(id),
  codigo           text NOT NULL,
  tipo_grupo       text NOT NULL CHECK (tipo_grupo IN (
                     'AULA','HIBRIDA','LAB','TALLER','ARTE','REMOTA','SIN_AULA')),
  tipo_detalle     text,
  piso             smallint,
  capacidad_real   int,
  capacidad_total  int,
  equipamiento     text[] NOT NULL DEFAULT '{}',
  activa           boolean NOT NULL DEFAULT true,
  UNIQUE (sede_id, codigo)
);

-- Skill 3: catálogo de materias (no es la clase)
CREATE TABLE materia (
  codigo         text PRIMARY KEY,
  nombre         text NOT NULL,
  facultad       text,
  departamento   text,
  carga_horaria  int
);

-- Dato, no motor ML. Viene del Excel / del sistema de DD.
CREATE TABLE docente (
  id      serial PRIMARY KEY,
  nombre  text UNIQUE NOT NULL
);

-- Skill 3: calendario de restricciones (no asigna día/turno)
CREATE TABLE periodo (
  id           smallserial PRIMARY KEY,
  ciclo        int NOT NULL,
  nombre       text NOT NULL,
  fecha_desde  date,
  fecha_hasta  date,
  UNIQUE (ciclo, nombre)
);

-- Skill 3: la clase (comisión) ya nace con turno, día, horario y docente
CREATE TABLE clase (
  id                       bigint PRIMARY KEY,
  nro_clase                int NOT NULL,
  periodo_id               smallint NOT NULL REFERENCES periodo(id),
  sede_id                  smallint NOT NULL REFERENCES sede(id),
  materia_codigo           text NOT NULL REFERENCES materia(codigo),
  turno                    text NOT NULL CHECK (turno IN ('MANANA','TARDE','NOCHE')),
  horario_desde            time NOT NULL,
  horario_hasta            time NOT NULL,
  dias                     text[] NOT NULL,
  regimen                  text NOT NULL,
  idioma                   text,
  modalidad                text,
  -- Skill 1: demanda (número; solicitudes individuales = fase 2)
  inscriptos               int NOT NULL DEFAULT 0,
  inscriptos_con_reserva   int NOT NULL DEFAULT 0,
  packs                    text[] NOT NULL DEFAULT '{}'
);

CREATE TABLE clase_docente (
  clase_id    bigint NOT NULL REFERENCES clase(id) ON DELETE CASCADE,
  docente_id  int NOT NULL REFERENCES docente(id),
  PRIMARY KEY (clase_id, docente_id)
);

-- Skill 4: resultado del cuadre (aula sugerida o heredada del Excel)
CREATE TABLE asignacion (
  id        serial PRIMARY KEY,
  clase_id  bigint NOT NULL UNIQUE REFERENCES clase(id) ON DELETE CASCADE,
  aula_id   int REFERENCES aula(id),
  origen    text NOT NULL CHECK (origen IN ('EXCEL','SUGERIDA','MANUAL')),
  sillas_vacias int
);

CREATE INDEX idx_clase_sede_turno ON clase (sede_id, turno);
CREATE INDEX idx_clase_dias ON clase USING gin (dias);
CREATE INDEX idx_asignacion_aula ON asignacion (aula_id);

COMMIT;
