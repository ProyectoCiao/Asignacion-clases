#!/usr/bin/env python3
"""Convierte el Excel de clases UADE al schema de 01_schema.sql."""
from __future__ import annotations

import argparse
import re
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

import openpyxl

EXCEL_EPOCH = date(1899, 12, 30)


def sql_str(v) -> str:
    if v is None:
        return "NULL"
    s = str(v).replace("'", "''")
    return "'" + s + "'"


def sql_int(v):
    if v is None or v == "" or v == "-":
        return "NULL"
    try:
        return str(int(float(v)))
    except (TypeError, ValueError):
        return "NULL"


def sql_array(items) -> str:
    clean = [x.strip() for x in items if x and str(x).strip() and str(x).strip() != "-"]
    if not clean:
        return "'{}'"
    inner = ",".join('"' + x.replace('\\', '\\\\').replace('"', '\\"') + '"' for x in clean)
    return "'{" + inner.replace("'", "''") + "}'"


def excel_date(n):
    if n is None or n == "" or n == "-":
        return None
    try:
        return EXCEL_EPOCH + timedelta(days=int(n))
    except (TypeError, ValueError):
        return None


def parse_horario(h: str):
    parts = re.split(r"\s*-\s*", str(h).strip())
    if len(parts) != 2:
        raise ValueError(f"horario inválido: {h}")
    return parts[0], parts[1]


def parse_dias(raw) -> list[str]:
    if not raw:
        return []
    return [d.strip() for d in str(raw).split("-") if d.strip()]


def tipo_de(codigo: str) -> tuple[str, str]:
    c = (codigo or "").strip()
    if c in ("", "-", "CLASE REMOTA"):
        return ("REMOTA" if c == "CLASE REMOTA" else "SIN_AULA", c or "-")
    detalle = c.split("-", 1)[1] if "-" in c else c
    u = detalle.upper()
    if "HÍBRIDA" in detalle.upper() or "HIBRIDA" in u:
        grupo = "HIBRIDA"
    elif "ARTE" in u:
        grupo = "ARTE"
    elif "TALLER" in u:
        grupo = "TALLER"
    elif "LAB" in u or "INFORMATICA" in u or "INFORMÁTICA" in detalle.upper():
        grupo = "LAB"
    else:
        grupo = "AULA"
    return grupo, detalle


def piso_de(codigo: str, sede: str):
    c = (codigo or "").strip()
    if c in ("", "-", "CLASE REMOTA"):
        return None
    token = c.split("-", 1)[0]
    if token.lower().startswith("s"):
        return 0
    if sede == "PINAMAR" and token.upper().startswith("P") and len(token) >= 2:
        rest = token[1:]
        if rest[:1].isdigit():
            return int(rest[0])
        return None
    digits = re.sub(r"\D", "", token)
    if not digits:
        return None
    if len(digits) >= 4:
        return int(digits[:2])
    return int(digits[0])


def equipamiento(grupo: str, detalle: str) -> list[str]:
    tags = []
    u = (detalle or "").upper()
    if grupo == "HIBRIDA" or "HÍBRIDA" in (detalle or "").upper():
        tags.append("hibrida")
    if grupo == "LAB":
        tags.append("lab")
    if "MAC" in u:
        tags.append("mac")
    if "PROYECTOR" in u:
        tags.append("proyector")
    if grupo == "TALLER":
        tags.append("taller")
    if grupo == "ARTE":
        tags.append("arte")
    if "VIDEOJUEGO" in u:
        tags.append("videojuegos")
    if "FIN" in u and "LAB" in u:
        tags.append("finanzas")
    if "IDIOMA" in u:
        tags.append("idiomas")
    return tags


def turno_norm(t: str) -> str:
    t = (t or "").upper()
    if t == "MAÑANA" or t == "MANANA":
        return "MANANA"
    return t


def split_docentes(raw) -> list[str]:
    if not raw or str(raw).strip() == "-":
        return []
    return [p.strip() for p in str(raw).split(" - ") if p.strip()]


def split_packs(raw) -> list[str]:
    if not raw or str(raw).strip() == "-":
        return []
    return [p.strip() for p in str(raw).split(",") if p.strip() and p.strip() != "-"]


def load_rows(path: Path):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.active
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    h = {name: i for i, name in enumerate(headers)}
    rows = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[h["Id"]] is None:
            continue
        rows.append({k: r[i] for k, i in h.items()})
    return rows


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--excel", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args()
    rows = load_rows(Path(args.excel))

    sedes = {}
    order_sedes = []
    for codigo, nombre in [
        ("MONSERRAT", "Campus Buenos Aires — Monserrat"),
        ("BELGRANO", "UADE Belgrano"),
        ("PINAMAR", "Campus Costa Argentina — Pinamar"),
    ]:
        sedes[codigo] = None
        order_sedes.append((codigo, nombre))
    for r in rows:
        if r["Sede"] not in sedes:
            sedes[r["Sede"]] = None
            order_sedes.append((r["Sede"], r["Sede"]))

    periodos = {}
    for r in rows:
        key = (int(r["Ciclo"]), str(r["Periodo"]))
        d0, d1 = excel_date(r["Desde"]), excel_date(r["Hasta"])
        if key not in periodos:
            periodos[key] = [d0, d1]
        else:
            if d0 and (periodos[key][0] is None or d0 < periodos[key][0]):
                periodos[key][0] = d0
            if d1 and (periodos[key][1] is None or d1 > periodos[key][1]):
                periodos[key][1] = d1

    materias = {}
    for r in rows:
        materias[str(r["CódigoMateria"])] = (
            r["Materia"],
            r["Facultad"],
            r["Departamento"],
            r["CargaHorariaMateria"],
        )

    docentes = []
    seen_doc = set()
    for r in rows:
        for n in split_docentes(r["Docentes"]):
            if n not in seen_doc:
                seen_doc.add(n)
                docentes.append(n)

    aulas = {}  # (sede, codigo) -> dict
    for r in rows:
        sede = r["Sede"]
        codigo = str(r["Aula Principal"] or "-").strip() or "-"
        grupo, detalle = tipo_de(codigo)
        key = (sede, codigo)
        cr = r["Capacidad Real"]
        ct = r["Capacidad Total"]
        try:
            cr_n = int(float(cr)) if cr not in (None, "", "-") else None
        except (TypeError, ValueError):
            cr_n = None
        try:
            ct_n = int(float(ct)) if ct not in (None, "", "-") else None
        except (TypeError, ValueError):
            ct_n = None
        if key not in aulas:
            aulas[key] = {
                "sede": sede,
                "codigo": codigo,
                "grupo": grupo,
                "detalle": detalle,
                "piso": piso_de(codigo, sede),
                "cr": cr_n,
                "ct": ct_n,
                "eq": equipamiento(grupo, detalle),
            }
        else:
            a = aulas[key]
            if cr_n is not None:
                a["cr"] = cr_n if a["cr"] is None else max(a["cr"], cr_n)
            if ct_n is not None:
                a["ct"] = ct_n if a["ct"] is None else max(a["ct"], ct_n)

    lines = [
        "-- Datos generados desde el Excel recortado de clases UADE.",
        "-- No editar a mano; regenerar con importar_excel.py",
        "BEGIN;",
        "TRUNCATE asignacion, clase_docente, clase, docente, materia, aula, periodo, sede RESTART IDENTITY CASCADE;",
        "",
        "-- sedes",
    ]
    for i, (codigo, nombre) in enumerate(order_sedes, 1):
        sedes[codigo] = i
        lines.append(
            f"INSERT INTO sede (id, codigo, nombre) VALUES ({i}, {sql_str(codigo)}, {sql_str(nombre)});"
        )
    lines.append(f"SELECT setval('sede_id_seq', {len(order_sedes)});")

    lines.append("")
    lines.append("-- periodos")
    periodo_ids = {}
    for i, ((ciclo, nombre), (d0, d1)) in enumerate(sorted(periodos.items()), 1):
        periodo_ids[(ciclo, nombre)] = i
        ds = sql_str(d0.isoformat()) if d0 else "NULL"
        hs = sql_str(d1.isoformat()) if d1 else "NULL"
        lines.append(
            f"INSERT INTO periodo (id, ciclo, nombre, fecha_desde, fecha_hasta) "
            f"VALUES ({i}, {ciclo}, {sql_str(nombre)}, {ds}, {hs});"
        )
    lines.append(f"SELECT setval('periodo_id_seq', {max(len(periodo_ids), 1)});")

    lines.append("")
    lines.append("-- materias")
    for codigo, (nombre, fac, depto, carga) in sorted(materias.items()):
        lines.append(
            "INSERT INTO materia (codigo, nombre, facultad, departamento, carga_horaria) VALUES ("
            f"{sql_str(codigo)}, {sql_str(nombre)}, {sql_str(fac)}, {sql_str(depto)}, {sql_int(carga)});"
        )

    lines.append("")
    lines.append("-- docentes (dato, no ML)")
    doc_ids = {}
    for i, n in enumerate(docentes, 1):
        doc_ids[n] = i
        lines.append(f"INSERT INTO docente (id, nombre) VALUES ({i}, {sql_str(n)});")
    if docentes:
        lines.append(f"SELECT setval('docente_id_seq', {len(docentes)});")

    lines.append("")
    lines.append("-- aulas")
    aula_ids = {}
    for i, key in enumerate(sorted(aulas.keys(), key=lambda k: (k[0], k[1])), 1):
        a = aulas[key]
        aula_ids[key] = i
        piso = "NULL" if a["piso"] is None else str(a["piso"])
        lines.append(
            "INSERT INTO aula (id, sede_id, codigo, tipo_grupo, tipo_detalle, piso, "
            "capacidad_real, capacidad_total, equipamiento) VALUES ("
            f"{i}, {sedes[a['sede']]}, {sql_str(a['codigo'])}, {sql_str(a['grupo'])}, "
            f"{sql_str(a['detalle'])}, {piso}, {sql_int(a['cr'])}, {sql_int(a['ct'])}, "
            f"{sql_array(a['eq'])});"
        )
    if aulas:
        lines.append(f"SELECT setval('aula_id_seq', {len(aulas)});")

    lines.append("")
    lines.append("-- clases + demanda + asignacion excel")
    cd_rows = []
    asg_rows = []
    for r in rows:
        cid = int(r["Id"])
        ciclo = int(r["Ciclo"])
        per = str(r["Periodo"])
        sede = r["Sede"]
        hd, hh = parse_horario(r["Horario"])
        dias = parse_dias(r["Dias De Cursada"])
        packs = split_packs(r["Packs Asociados"])
        lines.append(
            "INSERT INTO clase (id, nro_clase, periodo_id, sede_id, materia_codigo, turno, "
            "horario_desde, horario_hasta, dias, regimen, idioma, modalidad, "
            "inscriptos, inscriptos_con_reserva, packs) VALUES ("
            f"{cid}, {int(r['Clase'])}, {periodo_ids[(ciclo, per)]}, {sedes[sede]}, "
            f"{sql_str(r['CódigoMateria'])}, {sql_str(turno_norm(r['Turno']))}, "
            f"{sql_str(hd)}, {sql_str(hh)}, {sql_array(dias)}, {sql_str(r['Régimen'])}, "
            f"{sql_str(r['Idioma'])}, {sql_str(r['Modalidad'])}, "
            f"{sql_int(r['Inscriptos Por ClaseSin Considerar Reservas'])}, "
            f"{sql_int(r['Inscriptos Por Clase Con Reserva'])}, {sql_array(packs)});"
        )
        for n in split_docentes(r["Docentes"]):
            cd_rows.append((cid, doc_ids[n]))
        codigo = str(r["Aula Principal"] or "-").strip() or "-"
        aid = aula_ids[(sede, codigo)]
        grupo = aulas[(sede, codigo)]["grupo"]
        aula_fk = "NULL" if grupo in ("REMOTA", "SIN_AULA") else str(aid)
        insc = r["Inscriptos Por Clase Con Reserva"]
        ct = aulas[(sede, codigo)]["ct"]
        vacias = "NULL"
        try:
            if grupo not in ("REMOTA", "SIN_AULA") and ct is not None and insc not in (None, "", "-"):
                vacias = str(int(ct) - int(float(insc)))
        except (TypeError, ValueError):
            vacias = "NULL"
        asg_rows.append((cid, aula_fk, vacias))

    lines.append("")
    for cid, did in cd_rows:
        lines.append(
            f"INSERT INTO clase_docente (clase_id, docente_id) VALUES ({cid}, {did});"
        )
    lines.append("")
    for cid, aula_fk, vacias in asg_rows:
        lines.append(
            "INSERT INTO asignacion (clase_id, aula_id, origen, sillas_vacias) VALUES ("
            f"{cid}, {aula_fk}, 'EXCEL', {vacias});"
        )

    lines.append("COMMIT;")
    out = Path(args.out)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(
        f"Wrote {out} clases={len(rows)} aulas={len(aulas)} materias={len(materias)} docentes={len(docentes)}"
    )


if __name__ == "__main__":
    main()
