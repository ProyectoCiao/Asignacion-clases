-- Oferta, aulas, demanda de inscripción. Sin datos personales reales.

CREATE TABLE IF NOT EXISTS sede (
  id      smallserial PRIMARY KEY,
  codigo  text UNIQUE NOT NULL,
  nombre  text NOT NULL
);

CREATE TABLE IF NOT EXISTS aula (
  id               serial PRIMARY KEY,
  sede_id          smallint NOT NULL REFERENCES sede(id),
  codigo           text NOT NULL,
  tipo_grupo       text NOT NULL CHECK (tipo_grupo IN (
                     'AULA','HIBRIDA','LAB','TALLER','ARTE','REMOTA','SIN_AULA')),
  tipo_detalle     text,
  piso             smallint,
  capacidad_real   int,
  capacidad_total  int,
  equipamiento     text[] NOT NULL DEFAULT '{}',
  activa           boolean NOT NULL DEFAULT true,
  UNIQUE (sede_id, codigo)
);

CREATE TABLE IF NOT EXISTS materia (
  codigo         text PRIMARY KEY,
  nombre         text NOT NULL,
  facultad       text,
  departamento   text,
  carga_horaria  int
);

CREATE TABLE IF NOT EXISTS docente (
  id      serial PRIMARY KEY,
  nombre  text UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS periodo (
  id           smallserial PRIMARY KEY,
  ciclo        int NOT NULL,
  nombre       text NOT NULL,
  fecha_desde  date,
  fecha_hasta  date,
  UNIQUE (ciclo, nombre)
);

CREATE TABLE IF NOT EXISTS clase (
  id                       bigint PRIMARY KEY,
  nro_clase                int NOT NULL,
  periodo_id               smallint NOT NULL REFERENCES periodo(id),
  sede_id                  smallint NOT NULL REFERENCES sede(id),
  materia_codigo           text NOT NULL REFERENCES materia(codigo),
  turno                    text NOT NULL CHECK (turno IN ('MANANA','TARDE','NOCHE')),
  horario_desde            time NOT NULL,
  horario_hasta            time NOT NULL,
  dias                     text[] NOT NULL,
  regimen                  text NOT NULL,
  idioma                   text,
  modalidad                text,
  inscriptos               int NOT NULL DEFAULT 0,
  inscriptos_con_reserva   int NOT NULL DEFAULT 0,
  packs                    text[] NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS clase_docente (
  clase_id    bigint NOT NULL REFERENCES clase(id) ON DELETE CASCADE,
  docente_id  int NOT NULL REFERENCES docente(id),
  PRIMARY KEY (clase_id, docente_id)
);

CREATE TABLE IF NOT EXISTS asignacion (
  id            serial PRIMARY KEY,
  clase_id      bigint NOT NULL UNIQUE REFERENCES clase(id) ON DELETE CASCADE,
  aula_id       int REFERENCES aula(id),
  origen        text NOT NULL CHECK (origen IN ('EXCEL','SUGERIDA','MANUAL')),
  sillas_vacias int
);

CREATE INDEX IF NOT EXISTS idx_clase_sede_turno ON clase (sede_id, turno);
CREATE INDEX IF NOT EXISTS idx_asignacion_aula ON asignacion (aula_id);

CREATE TABLE IF NOT EXISTS carrera (
  id        serial PRIMARY KEY,
  codigo    text UNIQUE NOT NULL,
  nombre    text NOT NULL,
  facultad  text NOT NULL
);

CREATE TABLE IF NOT EXISTS materia_carrera (
  materia_codigo  text NOT NULL REFERENCES materia(codigo),
  carrera_id      int NOT NULL REFERENCES carrera(id),
  PRIMARY KEY (materia_codigo, carrera_id)
);

CREATE TABLE IF NOT EXISTS alumno (
  id          serial PRIMARY KEY,
  codigo      text UNIQUE NOT NULL,
  carrera_id  int NOT NULL REFERENCES carrera(id)
);

CREATE TABLE IF NOT EXISTS inscripcion (
  id              serial PRIMARY KEY,
  alumno_id       int NOT NULL REFERENCES alumno(id),
  materia_codigo  text NOT NULL REFERENCES materia(codigo),
  periodo_id      smallint NOT NULL REFERENCES periodo(id),
  solicitado_en   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (alumno_id, materia_codigo, periodo_id)
);

CREATE TABLE IF NOT EXISTS docente_materia (
  docente_id      int NOT NULL REFERENCES docente(id),
  materia_codigo  text NOT NULL REFERENCES materia(codigo),
  PRIMARY KEY (docente_id, materia_codigo)
);

CREATE TABLE IF NOT EXISTS demanda_snapshot (
  periodo_id       smallint NOT NULL REFERENCES periodo(id),
  materia_codigo   text NOT NULL REFERENCES materia(codigo),
  solicitudes      int NOT NULL,
  actualizado_en   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (periodo_id, materia_codigo)
);

CREATE TABLE IF NOT EXISTS oferta_meta (
  id                       smallint PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  demanda_actualizada_en   timestamptz,
  oferta_grabada_en        timestamptz
);

CREATE INDEX IF NOT EXISTS idx_inscripcion_materia ON inscripcion (periodo_id, materia_codigo);
